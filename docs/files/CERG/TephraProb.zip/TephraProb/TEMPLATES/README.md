# TephraProb: Cluster templates

*TephraProb* can be relatively easyly used on a cluster, and does not require the cluster to run Matlab. A description of the procedure is given [here](https://e5k.github.io/codes/2018/06/08/tephraprob-parallel/). This folder contains templates of job files that succeded in running on different cluster architectures.