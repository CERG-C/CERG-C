function [angle_rad]=deg2rad(angle_deg)

angle_rad=(angle_deg*2*pi)/360;