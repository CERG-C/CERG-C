# -*- coding: utf-8 -*-
"""
Created on Tue Mar  3 15:36:16 2020

@author: Mossoux sophie
"""

"""
This module is responsible for calculating the fitness index of a lava flow.
The fitness index compares the result of a simulation with a reference file.
"""

import math

import numpy as np

class sensitivity(Exception):
    """ This exeception is raised when the resolution of the reference and
    simulation do not match.
    """

def setup(Param, Min, Max, Step):
    
    



    return (Param, Min, Max, Step)