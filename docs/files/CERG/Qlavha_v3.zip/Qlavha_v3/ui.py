""" This module contains the UI code for Q-LavHA. """

import os.path
import itertools

import PyQt5.QtGui  as QTG
import PyQt5.QtCore as QTC
import qgis.core    as QGC
import PyQt5.QtWidgets as QTW

from qgis.core import QgsProject, QgsWkbTypes, QgsGeometry
from PyQt5 import QtWidgets

from .qlavha_ui   import Ui_lavaDialog

from . import util
from . import simulation


# ------------- #
# Custom Dialog #
# ------------- #

class CustomDialog (QTW.QDialog):
    """ We use a custom QDialog implementation to remove the focus from
        textfields when the user clicks on the dialog, and to emit an event
        when the window is shown.
    """
    dialogShown = QTC.pyqtSignal()

    def mousePressEvent(self, event):
        focusWidget = QtWidgets.QApplication.focusWidget()
        if focusWidget:
            focusWidget.clearFocus()

    def showEvent(self, event):
        super(CustomDialog, self).showEvent(event)
        self.dialogShown.emit()

# ---------------- #
# Custom Exception #
# ---------------- #

class MissingDataException(Exception):
    """ This exception is raised when required data is missing. """

# ----------------- #
# UI Implementation #
# ----------------- #

class UI (object):
    def __init__(self, iface):
        self.qgis      = iface

        self.container = CustomDialog()
        self.ui        = Ui_lavaDialog()

        self.setup()

    def setup(self):
        # Build the User Interface
        self.ui.setupUi(self.container)

        self.container.dialogShown.connect(lambda: self.update())

        # Remove help button from windows
        self.container.setWindowFlags(
            self.container.windowFlags() & ~QTC.Qt.WindowContextHelpButtonHint)

        # Attach buttons
        self.ui.cancelButton.clicked.connect(lambda: self.cancel())
        self.ui.runButton.clicked.connect(lambda: self.startSimulation())
        self.ui.resetButton.clicked.connect(lambda: self.reset())

        # Custom setup methods
        self.setupContextElements()
        self.setupFileSelection()
        self.setupInfoButtons()
        self.setupLayers()
        self.setupPages()

    def show(self):
        self.container.exec_()

    # ---------- #
    # Run Button #
    # ---------- #

    def startSimulation(self):
        # Save Parameters if needed
        if self.ui.savePathLine.text():
            util.qlc.save(self.ui, self.ui.savePathLine.text())

        try:
            outDir, outName = self.loadOutputFiles()
            dem = self.loadDem()
            fit = self.loadFitness()
            iter = self.textOrDefault(self.ui.iterationsLine, int)
            threshold = self.textOrDefault(
                self.ui.thresholdLine, lambda x : float(x) / 100.
            )
            ventList, probLst = self.loadVents(dem)
            flowTracker = self.loadFlowTracker(dem)
            stopTracker = self.loadStopTracker(dem)
            
            if self.ui.tableCheckBox.isChecked():
                if len(os.listdir(outDir)) != 0:                 
                    field = self.ui.outputBox
                    err = util.loadStringResource(":/txt/AlertFolderEmpty.txt")
                    self.openMessageBox(err)
                    self.focusField(field)
                    raise MissingDataException()
                    
            #start a loop to test different value for one same parameter
            if self.ui.sensitivityCheckBox.isChecked():
                steps = []
                
                sensitivityList = ["LENGTH - Euclidean length", "FLOWGO - Channel ratio", "FLOWGO - Effusion rate", 
                                   "Hc", "Hp", 
                                   "FLOWGO - Initial phenocryst mass fraction", "Iterations", 
                                   "FLOWGO - Lava initial viscosity", "LENGTH - Manhattan length", "LENGTH - Mean length",
                                   "LENGTH - Standard deviation", "Threshold (%)"]
                
                if self.ui.parameterBox.currentText() in sensitivityList:    
                    if self.ui.parameterBox.currentText() == "LENGTH - Euclidean length":
                        if self.ui.euclideanRadioBut.isChecked() == False:
                            self.paramOrError(self.ui.euclideanRadioBut, 'Euclidean radio button')
                        else:
                            try: 
                                minValue = self.textOrDefault(self.ui.minValue, int)
                                maxValue = self.textOrDefault(self.ui.maxValue, int)
                                stepValue = self.textOrDefault(self.ui.stepValue, int)
                                param = "euclideanLength"
                            except:
                                field = self.ui.minValue
                                err = util.loadStringResource(":/txt/AlertSensitivityIntValue.txt")
                                self.openMessageBox(err)
                                self.focusField(field)
                                raise MissingDataException()
                    elif self.ui.parameterBox.currentText() == "FLOWGO - Channel ratio":
                        if self.ui.flowgoRadioBut.isChecked() == False:
                            self.paramOrError(self.ui.flowgoRadioBut, 'FLOWGO radio button') 
                        else:
                            try :
                                minValue = self.textOrDefault(self.ui.minValue, int)
                                maxValue = self.textOrDefault(self.ui.maxValue, int)
                                stepValue = self.textOrDefault(self.ui.stepValue, int)
                                param = "channelRatio"
                            except:
                                field = self.ui.minValue
                                err = util.loadStringResource(":/txt/AlertSensitivityIntValue.txt")
                                self.openMessageBox(err)
                                self.focusField(field)
                                raise MissingDataException()
                    elif self.ui.parameterBox.currentText() == "FLOWGO - Effusion rate":
                        if self.ui.flowgoRadioBut.isChecked() == False:
                            self.paramOrError(self.ui.flowgoRadioBut, 'FLOWGO radio button')               
                        else:
                            try : 
                                minValue = self.textOrDefault(self.ui.minValue, int)
                                maxValue = self.textOrDefault(self.ui.maxValue, int)
                                stepValue = self.textOrDefault(self.ui.stepValue, int)
                                param = "effusionRate" 
                            except:
                                field = self.ui.minValue
                                err = util.loadStringResource(":/txt/AlertSensitivityIntValue.txt")
                                self.openMessageBox(err)
                                self.focusField(field)
                                raise MissingDataException()
                    elif self.ui.parameterBox.currentText() == "Hc":
                        minValue = self.textOrDefault(self.ui.minValue, float)
                        maxValue = self.textOrDefault(self.ui.maxValue, float)
                        stepValue = self.textOrDefault(self.ui.stepValue, float)
                        minValue = int(minValue*10000)
                        maxValue = int(maxValue*10000)
                        stepValue = int(stepValue*10000)
                        param = "hc"
                    elif self.ui.parameterBox.currentText() == "Hp":
                        minValue = self.textOrDefault(self.ui.minValue, float)
                        maxValue = self.textOrDefault(self.ui.maxValue, float)
                        stepValue = self.textOrDefault(self.ui.stepValue, float)
                        minValue = int(minValue*10000)
                        maxValue = int(maxValue*10000)
                        stepValue = int(stepValue*10000)
                        param = "hp"    
                    elif self.ui.parameterBox.currentText() == "FLOWGO - Initial phenocryst mass fraction":
                        if self.ui.flowgoRadioBut.isChecked() == False:
                            self.paramOrError(self.ui.flowgoRadioBut, 'FLOWGO radio button')  
                        else:
                            minValue = self.textOrDefault(self.ui.minValue, float)
                            maxValue = self.textOrDefault(self.ui.maxValue, float)
                            stepValue = self.textOrDefault(self.ui.stepValue, float)
                            minValue = int(minValue*10000)
                            maxValue = int(maxValue*10000)
                            stepValue = int(stepValue*10000)
                            param = "initPheno"
                    elif self.ui.parameterBox.currentText() == "Iterations":
                        try: 
                            minValue = self.textOrDefault(self.ui.minValue, int)
                            maxValue = self.textOrDefault(self.ui.maxValue, int)
                            stepValue = self.textOrDefault(self.ui.stepValue, int)
                            param = "iteration"         
                        except:
                                field = self.ui.minValue
                                err = util.loadStringResource(":/txt/AlertSensitivityIntValue.txt")
                                self.openMessageBox(err)
                                self.focusField(field)
                                raise MissingDataException()
                    elif self.ui.parameterBox.currentText() == "FLOWGO - Lava initial viscosity":
                        if self.ui.flowgoRadioBut.isChecked() == False:
                            self.paramOrError(self.ui.flowgoRadioBut, 'FLOWGO radio button')   
                        else:
                            minValue = self.textOrDefault(self.ui.minValue, float)
                            maxValue = self.textOrDefault(self.ui.maxValue, float)
                            stepValue = self.textOrDefault(self.ui.stepValue, float)
                            minValue = int(minValue*10000)
                            maxValue = int(maxValue*10000)
                            stepValue = int(stepValue*10000)
                            param = "initVisco" 
                    elif self.ui.parameterBox.currentText() == "LENGTH - Manhattan length":
                        if self.ui.manhattanRadioBut.isChecked() == False:
                            self.paramOrError(self.ui.manhattanRadioBut, 'Manhattan radio button')  
                        else:
                            try: 
                                minValue = self.textOrDefault(self.ui.minValue, int)
                                maxValue = self.textOrDefault(self.ui.maxValue, int)
                                stepValue = self.textOrDefault(self.ui.stepValue, int)
                                param = "manhattanLength" 
                            except:
                                field = self.ui.minValue
                                err = util.loadStringResource(":/txt/AlertSensitivityIntValue.txt")
                                self.openMessageBox(err)
                                self.focusField(field)
                                raise MissingDataException()
                    elif self.ui.parameterBox.currentText() == "LENGTH - Mean length":
                        if self.ui.decreasingProbRadioBut.isChecked() == False:
                            self.paramOrError(self.ui.decreasingProbRadioBut, 'Decreasing Probability radio button')  
                        else:
                            try :
                                minValue = self.textOrDefault(self.ui.minValue, int)
                                maxValue = self.textOrDefault(self.ui.maxValue, int)
                                stepValue = self.textOrDefault(self.ui.stepValue, int)
                                param = "meanLength" 
                            except:
                                field = self.ui.minValue
                                err = util.loadStringResource(":/txt/AlertSensitivityIntValue.txt")
                                self.openMessageBox(err)
                                self.focusField(field)
                                raise MissingDataException()
                    elif self.ui.parameterBox.currentText() == "LENGTH - Standard deviation":
                        if self.ui.decreasingProbRadioBut.isChecked() == False:
                            self.paramOrError(self.ui.decreasingProbRadioBut, 'Decreasing Probability radio button')   
                        else:
                            try:
                                minValue = self.textOrDefault(self.ui.minValue, int)
                                maxValue = self.textOrDefault(self.ui.maxValue, int)
                                stepValue = self.textOrDefault(self.ui.stepValue, int)
                                param = "StdDev" 
                            except:
                                field = self.ui.minValue
                                err = util.loadStringResource(":/txt/AlertSensitivityIntValue.txt")
                                self.openMessageBox(err)
                                self.focusField(field)
                                raise MissingDataException()
                    elif self.ui.parameterBox.currentText() == "Threshold (%)":
                        minValue = self.textOrDefault(self.ui.minValue, float)
                        maxValue = self.textOrDefault(self.ui.maxValue, float)
                        stepValue = self.textOrDefault(self.ui.stepValue, float)
                        minValue = int(minValue*10000)
                        maxValue = int(maxValue*10000)
                        stepValue = int(stepValue*10000)
                        param = "threshold"
                    
                    if minValue>maxValue :
                        field = self.ui.minValue
                        err = util.loadStringResource(':/txt/AlertSensitivityValue.txt')
                        self.openMessageBox(err)
                        self.focusField(field)
                        raise MissingDataException()
                    
                    if minValue == 0:
                        field = self.ui.minValue
                        err = util.loadStringResource(':/txt/AlertMinSensitivityValue.txt') 
                        self.openMessageBox(err)
                        self.focusField(field)
                        raise MissingDataException()
                                            
                    for i in range (minValue, maxValue+1, stepValue):
                        self.ui.progressBar.setValue(0)
                        fit = self.loadFitness()
                        if self.ui.parameterBox.currentText() == "LENGTH - Euclidean length":
                            stopTracker.lengthMax = i
                        elif self.ui.parameterBox.currentText() == "FLOWGO - Channel ratio":
                            stopTracker.channelRatio = i
                        elif self.ui.parameterBox.currentText() == "FLOWGO - Effusion rate":
                            stopTracker.effusionRate = i
                        elif self.ui.parameterBox.currentText() == "Hc":
                            flowTracker.hc = float(i/10000)
                            i = flowTracker.hc
                        elif self.ui.parameterBox.currentText() == "Hp":
                            flowTracker.hp = float(i/10000)
                            i = flowTracker.hp
                        elif self.ui.parameterBox.currentText() == "FLOWGO - Initial phenocryst mass fraction":
                            stopTracker.initialCrystalMass = float(i/10000)
                            i = stopTracker.initialCrystalMass
                        elif self.ui.parameterBox.currentText() == "Iterations":
                            iter = i
                        elif self.ui.parameterBox.currentText() == "FLOWGO - Lava initial viscosity":
                            stopTracker.initialViscosity = float(i/10000)
                            i = stopTracker.initialViscosity
                        elif self.ui.parameterBox.currentText() == "LENGTH - Manhattan length":
                            stopTracker.lengthMax = i
                        elif self.ui.parameterBox.currentText() == "LENGTH - Mean length":
                            stopTracker.mean = i
                        elif self.ui.parameterBox.currentText() == "LENGTH - Standard deviation":
                            stopTracker.stdev = i
                        elif self.ui.parameterBox.currentText() == "Threshold (%)":
                            threshold = float(i/10000)
                            i = threshold
                        
                        res = simulation.run(
                        dem,
                        flowTracker,
                        stopTracker,
                        iter,
                        threshold,
                        ventList,
                        probLst,
                        lambda x : self.updateProgress(x))
                    
                        if fit:
                            try:
                                fit = simulation.fitness.calculate(res, fit)
                            except simulation.fitness.FitnessResolutionException:
                                err = util.loadStringResource(':/txt/AlertFitnessRes.txt')
                                self.openMessageBox(err)
                                fit = None
                        
                        outNameLoop = outName+"_"+param+"_"+str(i)           
                        self.writeOutputFiles(outDir, outNameLoop, res, fit)
                        self.openLavaFlow(res)
                        
                        if self.ui.tableCheckBox.isChecked():
                            steps.append(i)
                
                if self.ui.parameterBox.currentText() == "Distance between vents":
                    if self.ui.pointRadioBut.isChecked() == True:
                            self.paramOrError(self.ui.lineRadioBut, 'linear fissure, surface area or PDF map option')  
                    else:
                        try:
                                minValue = self.textOrDefault(self.ui.minValue, int)
                                maxValue = self.textOrDefault(self.ui.maxValue, int)
                                stepValue = self.textOrDefault(self.ui.stepValue, int)
                                param = "DistVents"
                        except:
                            field = self.ui.minValue
                            err = util.loadStringResource(":/txt/AlertSensitivityIntValue.txt")
                            self.openMessageBox(err)
                            self.focusField(field)
                            raise MissingDataException()
                        
                    for i in range (minValue, maxValue + 1 , stepValue):
                        self.ui.progressBar.setValue(0)
                        fit = self.loadFitness()
                        distance = i
                        threshold = self.textOrDefault(self.ui.thresholdLine, lambda x : float(x) / 100.)
                        ventList, probLst = self.loadVentsDistLoop(dem, distance)  
                        
                        res = simulation.run(
                        dem,
                        flowTracker,
                        stopTracker,
                        iter,
                        threshold,
                        ventList,
                        probLst,
                        lambda x : self.updateProgress(x))
                    
                        if fit:
                            try:
                                fit = simulation.fitness.calculate(res, fit)
                            except simulation.fitness.FitnessResolutionException:
                                err = util.loadStringResource(':/txt/AlertFitnessRes.txt')
                                self.openMessageBox(err)
                                fit = None
                        
                        outNameLoop = outName+"_"+param+"_"+str(i)           
                        self.writeOutputFiles(outDir, outNameLoop, res, fit)
                        self.openLavaFlow(res) 
                        
                        if self.ui.tableCheckBox.isChecked():
                            steps.append(i)
                            
                if self.ui.tableCheckBox.isChecked():
                    util.table.createTable(param, steps, outDir)
                            
                self.container.accept()
                self.ui.progressBar.setValue(0)
                    
            else: 
                res = simulation.run(
                    dem,
                    flowTracker,
                    stopTracker,
                    iter,
                    threshold,
                    ventList,
                    probLst,
                    lambda x : self.updateProgress(x))
                
                if fit:
                    try:
                        fit = simulation.fitness.calculate(res, fit)
                    except simulation.fitness.FitnessResolutionException:
                        err = util.loadStringResource(':/txt/AlertFitnessRes.txt')
                        self.openMessageBox(err)
                        fit = None
     
                self.writeOutputFiles(outDir, outName, res, fit)
                self.openLavaFlow(res)
    
                self.container.accept()
                self.ui.progressBar.setValue(0)

        except MissingDataException:
            pass
        except simulation.SimulationStoppedException:
            pass
        except Exception:
            path = os.path.join(outDir, outName) + "-error.txt"
            util.writeErr(path)
            err = util.loadStringResource(':/txt/AlertSimulationError.txt')
            err = err % path
            self.openMessageBox(err)


    def loadDem(self):
        path = self.textOrError(
            self.ui.demPathLine,
            'Digital Elevation Model (DEM)'
        )
        return self.loadAscFile(path, 'DEM')

    def loadFitness(self):
        if self.ui.fitnessCheckBox.isChecked():
            path = self.textOrError(
                self.ui.fitnessPathLine,
                'Real lava path for Fitness Index'
            )
            return self.loadAscFile(path, 'real lava flow')
        else:
            return None

    def loadFlowTracker(self, dem):
        hc = self.textOrDefault(self.ui.hcLine, float)
        hp = self.textOrDefault(self.ui.hpLine, float)
        sq = self.ui.squareProbsCheckBox.isChecked()
        ul = self.ui.h16CheckBox.isChecked()
        return simulation.flowtracker.FlowTracker(dem, hc, hp, sq, ul)

    def loadStopTracker(self, dem):
        if self.ui.manhattanRadioBut.isChecked():                              
            length = self.textOrDefault(self.ui.manhattanLine, float)
            return simulation.stoptracker.LavaLength(dem, length)
        if self.ui.euclideanRadioBut.isChecked():
            length = self.textOrDefault(self.ui.euclideanLine, float)
            return simulation.stoptracker.LavaAZLength(dem, length)
        if self.ui.decreasingProbRadioBut.isChecked():
            mean = self.textOrDefault(self.ui.meanLengthLine, float)
            stdd = self.textOrDefault(self.ui.standardDevLine, float)
            return simulation.stoptracker.DecreasingProbability(dem, mean, stdd)
        if self.ui.flowgoRadioBut.isChecked():
            dct = self.createFlowGoDict()
            return simulation.stoptracker.FlowGo(dem, dct)
        
    def loadVentsDistLoop(self, dem, distance):
        if self.ui.lineRadioBut.isChecked():
            xStart = self.textOrError(self.ui.x1Line, 'x1', float)
            xEnd   = self.textOrError(self.ui.x2Line, 'x2', float)
            yStart = self.textOrError(self.ui.y1Line, 'y1', float)
            yEnd   = self.textOrError(self.ui.y2Line, 'y2', float)
            self.checkCoords(dem, ((xStart, yStart), (xEnd, yEnd)))

            return (
                simulation.calcLinePoints(
                    dem, distance, (xStart, yStart), (xEnd, yEnd)
                ), None
            )
        if self.ui.surfaceRadioBut.isChecked():
            x1 = self.textOrError(self.ui.x1Line, 'x1', float)
            y1 = self.textOrError(self.ui.y1Line, 'y1', float)
            x2 = self.textOrError(self.ui.x2Line, 'x2', float)
            y2 = self.textOrError(self.ui.y2Line, 'y2', float)
            x3 = self.textOrError(self.ui.x3Line, 'x3', float)
            y3 = self.textOrError(self.ui.y3Line, 'y3', float)
            x4 = self.textOrError(self.ui.x4Line, 'x4', float)
            y4 = self.textOrError(self.ui.y4Line, 'y4', float)
            self.checkCoords(dem, ((x1, y1), (x2, y2), (x3, y3), (x4, y4)))

            return (
                simulation.calcSurfacePoints(
                    dem, distance,
                    (x1, y1),(x2, y2),(x3, y3),(x4, y4)
                ), None
            )
        if self.ui.pdfRadioBut.isChecked():
            pdf    = self.textOrError(self.ui.pdfPathLine, 'PDF file')
            pdf    = self.loadAscFile(pdf, 'PDF file')
            thresh = self.textOrError(
                self.ui.pdfValueLine, 'Minimum pdf Value', float
            )
            llX = self.textOrError(self.ui.x1Line, 'x1', float)
            llY = self.textOrError(self.ui.y1Line, 'y1', float)
            trX = self.textOrError(self.ui.x2Line, 'x2', float)
            trY = self.textOrError(self.ui.y2Line, 'y3', float)
            llX, llY = pdf.llX, pdf.llY
            trX, trY = pdf.getTopRightCoord()

            dLlX, dLlY = dem.llX, dem.llY
            dTrX, dTrY = dem.getTopRightCoord()

            if llX < dLlX or llY < dLlY or trX > dTrX or trY > dTrY:
                err = util.loadStringResource(':/txt/AlertPdfSize.txt')
                self.openMessageBox(err)
                raise MissingDataException()

            coords = simulation.calcSurfaceCoords(
                pdf, distance,
                (llX, trY), (trX, trY), (trX, llY), (llX, llY)
            )
            points, probs = simulation.calcPdfPoints(dem, pdf, thresh, coords)
            if len(points) == 0:
                err = util.loadStringResource(':/txt/AlertNoPdfValue.txt')
                self.openMessageBox(err)
                raise MissingDataException()
                
            if distance > abs(llX-trX) or distance > abs(llY-trY):
                err = util.loadStringResource(':/txt/AlertDistance.txt')
                self.openMessageBox(err)
                raise MissingDataException()
            
            return (points, probs)    

        else:
            err = util.loadStringResource(':/txt/AlertCoordsMissing.txt')
            self.openMessageBox(err)
            self.focusField(self.ui.layerComboBox)
            raise MissingDataException()

    def loadVents(self, dem):
        if self.ui.pointRadioBut.isChecked():
            x = self.textOrError(self.ui.x1Line, 'x1', float)
            y = self.textOrError(self.ui.y1Line, 'y1', float)
            self.checkCoords(dem, ((x, y),))
            return ((dem.convertCoord(x, y),), None)
        if self.ui.lineRadioBut.isChecked():
            xStart = self.textOrError(self.ui.x1Line, 'x1', float)
            xEnd   = self.textOrError(self.ui.x2Line, 'x2', float)
            yStart = self.textOrError(self.ui.y1Line, 'y1', float)
            yEnd   = self.textOrError(self.ui.y2Line, 'y2', float)
            self.checkCoords(dem, ((xStart, yStart), (xEnd, yEnd)))
            distance = self.textOrDefault(
                self.ui.distanceLine, float
            )
            return (
                simulation.calcLinePoints(
                    dem, distance, (xStart, yStart), (xEnd, yEnd)
                ), None
            )
        if self.ui.surfaceRadioBut.isChecked():
            x1 = self.textOrError(self.ui.x1Line, 'x1', float)
            y1 = self.textOrError(self.ui.y1Line, 'y1', float)
            x2 = self.textOrError(self.ui.x2Line, 'x2', float)
            y2 = self.textOrError(self.ui.y2Line, 'y2', float)
            x3 = self.textOrError(self.ui.x3Line, 'x3', float)
            y3 = self.textOrError(self.ui.y3Line, 'y3', float)
            x4 = self.textOrError(self.ui.x4Line, 'x4', float)
            y4 = self.textOrError(self.ui.y4Line, 'y4', float)
            self.checkCoords(dem, ((x1, y1), (x2, y2), (x3, y3), (x4, y4)))
            distance = self.textOrDefault(
                self.ui.distanceLine, float
            )
            return (
                simulation.calcSurfacePoints(
                    dem, distance,
                    (x1, y1),(x2, y2),(x3, y3),(x4, y4)
                ), None
            )
        if self.ui.pdfRadioBut.isChecked():
            pdf    = self.textOrError(self.ui.pdfPathLine, 'PDF file')
            pdf    = self.loadAscFile(pdf, 'PDF file')
            thresh = self.textOrError(
                self.ui.pdfValueLine, 'Minimum pdf Value', float
            )
            dist   = self.textOrDefault(
                self.ui.distanceLine, float
            )

            llX, llY = pdf.llX, pdf.llY
            trX, trY = pdf.getTopRightCoord()

            dLlX, dLlY = dem.llX, dem.llY
            dTrX, dTrY = dem.getTopRightCoord()

            if llX < dLlX or llY < dLlY or trX > dTrX or trY > dTrY:
                err = util.loadStringResource(':/txt/AlertPdfSize.txt')
                self.openMessageBox(err)
                raise MissingDataException()

            coords = simulation.calcSurfaceCoords(
                pdf, dist,
                (llX, trY), (trX, trY), (trX, llY), (llX, llY)
            )
            points, probs = simulation.calcPdfPoints(dem, pdf, thresh, coords)
            if len(points) == 0:
                err = util.loadStringResource(':/txt/AlertNoPdfValue.txt')
                self.openMessageBox(err)
                raise MissingDataException()
                
            if dist > abs(llX-trX) or dist > abs(llY-trY):
                err = util.loadStringResource(':/txt/AlertDistance.txt')
                self.openMessageBox(err)
                raise MissingDataException()
            
            return (points, probs)    

        else:
            err = util.loadStringResource(':/txt/AlertCoordsMissing.txt')
            self.openMessageBox(err)
            self.focusField(self.ui.layerComboBox)
            raise MissingDataException()

    def checkCoords(self, dem, lst):
        for x, y in lst:
            if util.numLength(x) <= 2 or util.numLength(y) <= 2:
                err = util.loadStringResource(':/txt/AlertIncorrectCoord.txt')
                self.openMessageBox(err)
                raise MissingDataException()
            if not dem.checkCoord(x, y):
                err = util.loadStringResource(':/txt/AlertCoord.txt') % (x, y)
                self.openMessageBox(err)
                raise MissingDataException()

    def loadOutputFiles(self):
        dir = self.textOrError(self.ui.outputPathLine, 'output path')
        nam = self.textOrError(self.ui.outputFileLine, 'output name')
        return (dir, nam)

    def writeOutputFiles(self, dir, name, raster, fitness):
        raster.toAsc(os.path.join(dir, name))
        util.summary.write(os.path.join(dir, name), self.ui, raster, fitness)
 
    def openLavaFlow(self, res):
        # Generate a unique layer name
        name     = res.name
        registry = QgsProject.instance()
        layers   = registry.mapLayersByName(name)
        if layers != []:
            for l in layers:
                registry.removeMapLayer(l)

        # Open the resulting DEM and color it
        layer = self.qgis.addRasterLayer(res.path, name)
        layer.loadNamedStyle(':/color/Lava.qml')

    def textOrDefault(self, field, convert = lambda x : x):
        txt = field.text()
        if txt: return convert(txt)
        txt = field.placeholderText()
        if txt: return convert(txt)

    def focusField(self, field):
        # Find the index of the parent tab
        idx  = None
        par  = field
        tabW = self.ui.tabWidget
        tabs = [tabW.widget(i) for i in range(tabW.count())]

        while par is not None:
            par = par.parentWidget()
            if par in tabs:
                idx = tabW.indexOf(par)
                break

        # Activate the tab of the missing item and give it focus.
        tabW.setCurrentIndex(idx)
        field.setFocus()

    def textOrError(self, field, name, convert = lambda x : x):
        txt = field.text()
        if txt: return convert(txt)

        err = util.loadStringResource(':/txt/AlertMissing.txt') % name
        self.openMessageBox(err)
        self.focusField(field)
        raise MissingDataException()
        
    def paramOrError(self, field, name, convert = lambda x : x):
        err = util.loadStringResource(':/txt/AlertWrongSelection.txt') % name
        self.openMessageBox(err)
        self.focusField(field)
        raise MissingDataException()

    def createFlowGoDict(self):
        return {
            'effusionRate' :
                self.textOrDefault(self.ui.effusionLine,  float),
            'channelRatio' :
                self.textOrDefault(self.ui.channelRatioLine, float),
            'gravity' :
                self.textOrDefault(self.ui.gravityLine, float),
            'initialViscosity' :
                self.textOrDefault(self.ui.viscosityLine, float),
            'viscosityConstA' :
                self.textOrDefault(self.ui.aLine, float),
            'viscosityConstB' :
                self.textOrDefault(self.ui.bLine, float),
            'viscosityConstC' :
                self.textOrDefault(self.ui.cLine, float),
            'emissivity' :
                self.textOrDefault(self.ui.eLine, float),
            'stephanBoltzmannConst' :
                self.textOrDefault(self.ui.sbcLine, float),
            'crustThickness' :
                self.textOrDefault(self.ui.thicknessLine, float),
            'lavaThermalConductivity' :
                self.textOrDefault(self.ui.thermalConductivityLine, float),
            'crustTemp' :
                self.textOrDefault(self.ui.crustTempLine, util.cToK),
            'eruptionTemp' :
                self.textOrDefault(self.ui.eruptionLine, util.cToK),
            'crustBaseTemp' :
                self.textOrDefault(self.ui.crustBaseTempLine, util.cToK),
            'coreCrustTempOffset' :
                self.textOrDefault(self.ui.tempOffsetLine, float),
            'thermalConductivityConstant' :
                self.textOrDefault(self.ui.dLine, float),
            'denseRockEquivalentDensity' :
                self.textOrDefault(self.ui.dreLine, float),
            'vesicularity' :
                self.textOrDefault(self.ui.vesicularityLine, float),
            'airTemp' :
                self.textOrDefault(self.ui.airTempLine, util.cToK),
            'windSpeed' :
                self.textOrDefault(self.ui.windSpeedLine, float),
            'airDensity' :
                self.textOrDefault(self.ui.airDensityLine, float),
            'windFriction' :
                self.textOrDefault(self.ui.chLine, float),
            'airHeatCapacity' :
                self.textOrDefault(self.ui.heatCapacityLine, float),
            'growthRate' :
                self.textOrDefault(self.ui.growthLine, float),
            'latentHeat' :
                self.textOrDefault(self.ui.lLine, float),
            'initialCrystalMass' :
                self.textOrDefault(self.ui.initialCrystLine, float),
            'inverseCrystalConc' :
                self.textOrDefault(self.ui.rLine, float)
         }

    # ----- #
    # Reset #
    # ----- #

    def reset(self):
        global __ui__
        self.container.close()
        __ui__ = None
        load(self.qgis)


    # ------ #
    # Cancel #
    # ------ #

    def cancel(self):
        simulation.stopSimulation()
        self.container.close()

    # ------ #
    # Update #
    # ------ #

    def update(self):
        self.updateLayers()

    # ------------ #
    # Progress Bar #
    # ------------ #

    def updateProgress(self, nmbr):
        self.ui.progressBar.setValue(int(nmbr))
        QtWidgets.QApplication.processEvents()

    # -------------- #
    # Page Selection #
    # -------------- #

    def setupPages(self):
        pages = (
            # Every entry in this list should be a tuple of which the first
            # element is a stacked widget. The second element should be a
            # list/tuple of buttons.
            # For each of these tuples, when the first button is pressed, the
            # first page of the stacked widget will be presented, when the
            # second button is pressed, the second page will be presented and
            # so on.
            # If multiple radio button select the same page, a tuple of radio
            # buttons can also be used.
            (
                self.ui.lengthStack,(
                    self.ui.manhattanRadioBut,
                    self.ui.euclideanRadioBut,
                    self.ui.decreasingProbRadioBut,
                    self.ui.flowgoRadioBut
                )
            ),(
                self.ui.ventStack,(
                    (
                        self.ui.pointRadioBut,
                        self.ui.lineRadioBut,
                        self.ui.surfaceRadioBut
                    ),
                    self.ui.layerRadioBut,
                    self.ui.pdfRadioBut
                )
            )
        )

        for page, lst in pages:
            for idx, but in enumerate(lst):

                # Disable page by default
                page.setCurrentIndex(idx)
                page.currentWidget().setEnabled(False)

                # Switch page on radio button click
                if type(but) == tuple:
                    for b in but: self.attachPageToButton(b, page, idx)
                else: self.attachPageToButton(but, page, idx)

            # Enable the first page
            self.changePage(page, 0)

    def attachPageToButton(self, button, stack, index):
        button.clicked.connect(lambda: self.changePage(stack, index))

    def changePage(self, stack, newIndex):
        stack.currentWidget().setEnabled(False)
        stack.setCurrentIndex(newIndex)
        stack.currentWidget().setEnabled(True)

    # -------------------------- #
    # Context-Sensitive Elements #
    # -------------------------- #

    def setupContextElements(self):
        self.setupRadioButtons()
        self.setupCheckBoxes()
    
    def setupCheckBoxes(self):
        # Every entry in this list should be a tuple of which the first element
        # is a checkbox, and the second is a list.
        # When one of these buttons is enabled, the elements in the matching
        # list will be enabled as well. Similarly, when the button is disabled,
        # the elements will be disabled.
        checkBoxLst = (
            (
                self.ui.fitnessCheckBox,
                [self.ui.fitnessPathLine, self.ui.fitnessPathButton, self.ui.tableCheckBox]
            ),(
                self.ui.advancedParamsCheckBox,
                [self.ui.flowgoAdvancedBox]
            ),(
                self.ui.sensitivityCheckBox,
                [self.ui.sensitivityBox]
            )
        )

        for but, enableLst in checkBoxLst:
            self.attachElementsToButton(but, None, enableLst, [])
            self.updateContextElements(but, None, enableLst, [])

    def setupRadioButtons(self):
        # This is a list of lists.
        # There should be a list for each 'group' of radio buttons that
        # enable or disable sections a common part of the user interface.
        # Each entry in one of these lists should be a tuple of which the first
        # element is a radio button, the second element is a callback and a
        # third element which is (yet another) list.
        # When the radio button is enabled, every element in this deepest
        # list will enabled. Any elements enabled by other radio buttons in
        # the group will be disabled if they were not enabled by this button.
        # Furthermore, the callback provided as second element will be called.
        # None can be used instead of a callback.
        radioButtonLst = (
            (
                (
                    self.ui.pointRadioBut, None,
                    (
                        self.ui.x1Line, self.ui.y1Line,
                    )
                ),(
                    self.ui.lineRadioBut, None,
                    (
                        self.ui.distanceLine,
                        self.ui.x1Line, self.ui.x2Line,
                        self.ui.y1Line, self.ui.y2Line, 
                        
                    )
                ),(
                    self.ui.surfaceRadioBut, None,
                    (
                        self.ui.distanceLine,
                        self.ui.x1Line, self.ui.x2Line,
                        self.ui.x3Line, self.ui.x4Line,
                        self.ui.y1Line, self.ui.y2Line,
                        self.ui.y3Line, self.ui.y4Line,
                    )
                ),(
                    self.ui.layerRadioBut, None,
                    (
                        self.ui.distanceLine,
                    )
                ),(
                    self.ui.pdfRadioBut, lambda : self.loadPdfFile(),
                    (
                        self.ui.distanceLine,
                    )
                )
            ),
        )

        for group in radioButtonLst:
            groupItems = set()
            buttonList = []

            # For every button, add the items it enables to the set of items
            # if it's not in there yet.
            # Also store the button alongside it's enableList
            for button, callback, items in group:
                for item in items: groupItems.add(item)
                buttonList.append((button, callback, items))

            # Bind every button to an enable and disable list
            for button, cb, enableLst in buttonList:
                # We disable every item that is not in the enable list
                disableLst = [el for el in groupItems if el not in enableLst]
 
                self.attachElementsToButton(button, cb, enableLst, disableLst)

                # If the button is checked, update the ui
                if button.isChecked():
                    self.updateContextElements(
                        button, cb, enableLst, disableLst
                    )

    def attachElementsToButton(self, button, cb, enableLst, disableLst):
        button.clicked.connect(
            lambda: self.updateContextElements(
                button, cb, enableLst, disableLst
            )
        )

    def updateContextElements(self, el, cb, enableLst, disableLst):
        enable = el.isChecked()

        for el in enableLst:
            el.setEnabled(enable)
        for el in disableLst:
            el.setEnabled(not enable)
            el.clear()

        if cb: cb()

    # -------------------- #
    # Info Button Mappings #
    # -------------------- #

    def setupInfoButtons(self):
        btns = (
            # Every entry in this list should be a tuple of which the first
            # element is a button, and the second is a string. The file at
            # :/txt/<string>.txt will be loaded in a message box when the
            # button is clicked
            (self.ui.demInfoButton, 'InfoDEM'),
            (self.ui.fitnessInfoButton, 'InfoLOR'),
            (self.ui.layerInfoButton, 'InfoLayer'),
            (self.ui.usePDFInfoButton, 'InfoPDF'),
            (self.ui.ventDistanceInfoButton, 'InfoDistance'),
            (self.ui.heightInfoButton, 'InfoH'),
            (self.ui.squareProbsInfoButton, 'InfoSquare'),
            (self.ui.lengthConstraintsInfoButton, 'InfoStopping'),
            (self.ui.manhattanInfoButton, 'InfoLength'),
            (self.ui.euclideanInfoButton, 'InfoAZLength'),
            (self.ui.meanLengthInfoButton, 'InfoProb'),
            (self.ui.flowgoInfoButton, 'InfoFlowgo'),
            (self.ui.iterationInfoButton, 'InfoItera'),
            (self.ui.sensitivityInfoButton, 'InfoSensitivity'),
            (self.ui.ThresholdInfoButton, 'InfoThreshold'),
        )
        for but, file in btns:
            self.attachInfoButton(file, but)

    def attachInfoButton(self, fileName, button, title = "Q-LavHA"):
        button.clicked.connect(
            lambda: self.openMessageBoxFromFile(
                ':/txt/%s.txt' % fileName, title
            )
        )

    def openMessageBoxFromFile(self, path, title = "Q-LavHA"):
        self.openMessageBox(util.loadStringResource(path), title)

    def openMessageBox(self, text, title = "Q-LavHA"):
        QtWidgets.QMessageBox.information(
            self.container,
            title,
            text,
            QtWidgets.QMessageBox.Ok
        )

    # -------------- #
    # File Selection #
    # -------------- #

    LOADFILE = 0
    SAVEFILE = 1
    DIR      = 2

    def setupFileSelection(self):
        gridFileSelector = (
            "Arc/Info ASCII Grid (*.asc *.ASC);;"
            "GeoTiff (*.tiff *.tif *.TIFF *.TIF)"
        )
        qLavhaConfigFileSelector = "Q-LavHA config file (*.qlc)"


        lst = (
            # Every entry in this list should be a tuple of 5 elements:
            # a button, a lineEdit, an int, a string and a callable (or None)
            # This function will make the button open a file selection dialog,
            # which will write it's result to the lineEdit field. Additionally,
            # the lineEdit will be set to read only.
            # The integer should be equal to either `LOADFILE`, `SAVEFILE`,
            # or `DIR`. Use loadfile when you want to open an existing file,
            # savefile when you want to save a new file and dir when you want
            # to select a directory.
            # The string should represent a filter option as specified in the
            # pyqt documentation (some examples follow below)
            # The callback can be used to trigger an action when a file is
            # selected. Use None if you don't want to do anything.
            # Filters and callback are ignored when selecing a folder.
            (
                self.ui.demPathButton,
                self.ui.demPathLine,
                UI.LOADFILE,
                gridFileSelector,
                lambda self, path, line: self.checkGridFile(path, line)
            ),
            (
                self.ui.fitnessPathButton,
                self.ui.fitnessPathLine,
                UI.LOADFILE,
                gridFileSelector,
                lambda self, path, line: self.checkGridFile(path, line)
            ),
            (
                self.ui.outputPathButton,
                self.ui.outputPathLine,
                UI.DIR,
                "", None
            ),
            (
                self.ui.loadPathButton,
                self.ui.loadPathLine,
                UI.LOADFILE,
                qLavhaConfigFileSelector,
                lambda self, path, _: util.qlc.load(self.ui, path)
            ),
            (
                self.ui.savePathButton,
                self.ui.savePathLine,
                UI.SAVEFILE,
                qLavhaConfigFileSelector,
                None
            ),
            (
                self.ui.pdfPathButton,
                self.ui.pdfPathLine,
                UI.LOADFILE,
                gridFileSelector,
                lambda self, path, line: self.loadPdfPath(path, line)
            ),
            (
                self.ui.rowButton,
                self.ui.rowLine,
                UI.LOADFILE,
                "ESRI Shapefiles [OGR] (*.shp *.SHP)",
                lambda self, path, _: self.loadLayer(path)
            )
        )

        for but, lin, bool, filter, callback in lst:
            self.attachFileDialog(but, lin, bool, filter, callback)
            lin.setReadOnly(True)

    def attachFileDialog(self, button, lineEdit, file, filter, callback):
        if file == UI.LOADFILE:
            f = lambda : self.openFileDialog(False, lineEdit, filter, callback)
        elif file == UI.SAVEFILE:
            f = lambda: self.openFileDialog(True, lineEdit, filter, callback)
        elif file == UI.DIR:
            f = lambda : self.openDirDialog(lineEdit)

        button.clicked.connect(f)

    def openDirDialog(self, lineEdit):
        path = QtWidgets.QFileDialog.getExistingDirectory()
        lineEdit.setText(path)

    def openFileDialog(self, save, lineEdit, filter, callback):
        if save:
            path = QtWidgets.QFileDialog.getSaveFileName(filter = filter)
        else: 
            path = QtWidgets.QFileDialog.getOpenFileName(filter = filter)
        lineEdit.setText(path[0])
        if callback and path:
            callback(self, path, lineEdit)

    def loadAscFile(self, path, errName):
        try:
            return simulation.raster.Raster.fromAsc(path)
        except simulation.raster.AscResolutionException:
            err = util.loadStringResource(':/txt/AlertDxDy.txt') % errName
            self.openMessageBox(err)
            raise MissingDataException()


    def loadPdfPath(self, path, line):
        self.checkGridFile(path, line)
        self.loadPdfFile()

    def loadPdfFile(self):
        pdf = self.ui.pdfPathLine.text()
        if pdf == "": return

        try:
            pdf = simulation.raster.Raster.fromAsc(pdf)
        except simulation.raster.AscResolutionException:
            err = util.loadStringResource(':/txt/AlertDxDy.txt') % 'PDF'
            self.openMessageBox(err)
            self.ui.pdfPathLine.clear()
            return

        llX, llY = pdf.llX, pdf.llY
        trX, trY = pdf.getTopRightCoord()
        
        # Update the UI
        self.ui.x1Line.setText(str(llX))
        self.ui.y1Line.setText(str(trY))
        self.ui.x2Line.setText(str(trX))
        self.ui.y2Line.setText(str(trY))
        self.ui.x3Line.setText(str(trX))
        self.ui.y3Line.setText(str(llY))
        self.ui.x4Line.setText(str(llX))
        self.ui.y4Line.setText(str(llY))

    # --------------- #
    # File Conversion #
    # --------------- #

    def checkGridFile(self, path, line):
        pathextract = path[0]
        patth = pathextract.lower()
        if patth.lower().endswith(('.tiff', '.tif')):
            ascPath = '%s.asc' % os.path.splitext(patth)[0]
            line.setText(ascPath)
            if os.path.exists(ascPath):
                text = util.loadStringResource(':/txt/InfoConversionExists.txt')
                text = text % os.path.basename(ascPath)
                self.openMessageBox(text)
            else:
                util.convertTiffToAsc(patth, ascPath)
                text = util.loadStringResource(':/txt/InfoConversion.txt')
                text = text % (
                    os.path.basename(patth),
                    os.path.basename(ascPath)
                )
                self.openMessageBox(text)

    # --------------- #
    # Layer Selection #
    # --------------- #

    def setupLayers(self):
        self.ui.layerComboBox.activated.connect(self.layerSelected)

    def updateLayers(self):
        self.ui.layerComboBox.clear()
        layers = QgsProject.instance().mapLayers().items()
        for id, layer in layers:
            if layer.type() == QGC.QgsMapLayer.VectorLayer:
                self.addLayer(layer)

        self.ui.layerComboBox.setCurrentIndex(0)

    def layerSelected(self, idx):
        layer = self.ui.layerComboBox.itemData(idx)
        if layer is None: return

        type  = layer.geometryType()
        geom  = [f.geometry() for f in layer.getFeatures()]
        
        if type   == QgsWkbTypes.PointGeometry:
            geom = geom[0].asPoint()
            self.ui.x1Line.setText(str(geom.x()))
            self.ui.y1Line.setText(str(geom.y()))
            self.ui.pointRadioBut.click()
        elif type == QgsWkbTypes.LineGeometry:
            points = geom[0].asMultiPolyline()
            coord = points[0]
            self.ui.x1Line.setText(str(coord[0].x()))
            self.ui.y1Line.setText(str(coord[0].y()))
            self.ui.x2Line.setText(str(coord[1].x()))
            self.ui.y2Line.setText(str(coord[1].y()))
            self.ui.lineRadioBut.click()
        elif type == QgsWkbTypes.PolygonGeometry:
            points = geom[0].asMultiPolygon()
            coord = points[0]
            coords = coord [0]
            self.ui.x1Line.setText(str(coords[0].x()))
            self.ui.y1Line.setText(str(coords[0].y()))
            self.ui.x2Line.setText(str(coords[1].x()))
            self.ui.y2Line.setText(str(coords[1].y()))
            self.ui.x3Line.setText(str(coords[2].x()))
            self.ui.y3Line.setText(str(coords[2].y()))
            self.ui.x4Line.setText(str(coords[3].x()))
            self.ui.y4Line.setText(str(coords[3].y()))
            self.ui.surfaceRadioBut.click()
        self.ui.layerComboBox.setCurrentIndex(0)

    def loadLayer(self, path):
        path = str(path[0])
        name = os.path.split(os.path.basename(path))[0]
        layer = self.qgis.addVectorLayer(path, name, 'ogr')
        idx   = self.addLayer(layer)
        self.layerSelected(idx)
        self.ui.layerComboBox.setCurrentIndex(0)
        
    def addLayer(self, layer):
        if self.ui.layerComboBox.count() == 0:
            self.ui.layerComboBox.insertItem(0, "")
        self.ui.layerComboBox.insertItem(1, layer.name(), layer)
        return 1

__ui__ = None

def load(iface):
    global __ui__
    if not __ui__:
        __ui__ = UI(iface)
    __ui__.show()

