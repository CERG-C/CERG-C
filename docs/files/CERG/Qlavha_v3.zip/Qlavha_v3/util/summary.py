"""
This module is responsible for generating the summary file.
"""

import io
import os

from . import tree

__skeleton__ = """# Results
# -------

%s

# Input Parameters
# ----------------
%s

"""

# ------- #
# Results #
# ------- #

def generateResults(raster, fitness):
    result = rasterInfo(raster)
    if fitness: result += '\n\n' + fitnessIndex(fitness)
    return result

def rasterInfo(raster):
    return "Generated output: %s\nOutput resolution (m): %d" % (
        os.path.basename(raster.path), raster.resolution)

def fitnessIndex(fitness):
    return "#Fitness Indexes \ntrue positive:  %s\nfalse positive: %s\nfalse negative: %s\ncomposite score: %s\ncumulative probability within the lava flow: %s\ncumulative probability outside the lava flow: %s" % fitness


# ---------- #
# Parameters #
# ---------- #

def generateParams(ui):
    b = io.StringIO()
    tree.iter(
        lambda s       : writeSection(b, s),
        lambda _, u, n : writeEntry(ui, b, u, n),
        lambda _, n, o : writeSelect(ui, b, n, o)
    )
    s = b.getvalue()
    b.close()
    return s

def writeSection(buff, section):
    buff.write("\n# %s\n" % section)

def writeEntry(ui, buff, uiName, name):
    val = tree.getUiValue(ui, uiName, True)
    if val is not None:
        buff.write("%s: %s\n" % (name, val))

def writeSelect(ui, buff, name, options):
    option = [uiName__ for uiName__ in options if tree.getUiValue(ui, uiName__[0])][0][1]
    buff.write("%s: %s\n" % (name, option))


# ------- #
# General #
# ------- #

def create(ui, raster, fitness):
    return __skeleton__ % (
        generateResults(raster, fitness),
        generateParams(ui)
    )

def write(path, ui, raster, fitness):
    with open("%s-summary.txt" % path, 'w') as file:
        file.write(create(ui, raster, fitness))
