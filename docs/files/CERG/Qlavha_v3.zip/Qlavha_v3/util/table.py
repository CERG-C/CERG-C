# --------------------------------------------------------------------- #
# Create a table and graph of the fitness index of the sensitivity test #
# --------------------------------------------------------------------- #
import os
import matplotlib.pyplot as plt 
import csv
import re

def createTable (param, steps, outDir):
    documentList = []
    summaryFile = []
    tPos = []
    fPos = []
    fNeg = []
    cSco = []
    cumW = []
    cumO = []
    
    os.chdir(outDir)
    
    for document in os.listdir(outDir):
        if document.endswith("-summary.txt"):
            #extract all the files related to -summary.txt
            documentList.append(document.strip())
    
    #extract all the file related to the parameter which is analyzed       
    summaryFile = [s for s in documentList if param in s]
   
    for file in summaryFile:
        f = open(file, "r")   
        for i, line in enumerate(f):
            if i == 7:
                value = re.findall('\d*\.?\d+',line)[0]
                tPos.append(float(value))
            if i == 8:
                value = re.findall('\d*\.?\d+',line)[0]
                fPos.append(float(value))
            if i == 9:
                value = re.findall('\d*\.?\d+',line)[0]
                fNeg.append(float(value))
            if i == 10:
                value = re.findall('\d*\.?\d+',line)[0]
                cSco.append(float(value))
            if i == 11:
                value = re.findall('\d*\.?\d+',line)[0]
                cumW.append(float(value))
            if i == 12:
                value = re.findall('\d*\.?\d+',line)[0]
                cumO.append(float(value))
        f.close()
        
    #create the table
    csvName = "SensitivityTable_"+ param +".csv"
    with open(csvName, mode='w', newline="") as f:
        thewriter = csv.writer(f)
        thewriter.writerow([steps])
        thewriter.writerow([tPos])
        thewriter.writerow([fPos])
        thewriter.writerow([fNeg])
        thewriter.writerow([cSco])
        thewriter.writerow([cumW])
        thewriter.writerow([cumO])  
    
    #create the graph 
    plt.close()
    plt.plot(steps, tPos, label = "True Positive", color= "black")
    plt.plot(steps, fPos, label = "False Positive", color= "black", linestyle='dashed') 
    plt.plot(steps, fNeg, label = "False Negative", color= "black", linestyle='dotted')
    plt.plot(steps, cSco, label = "Composite Score", color= "blue")
    plt.plot(steps, cumW, label = "Cumulative Probability within the flow", color= "red")
    plt.xlabel(param) 
    plt.ylabel("indexes") 
    # create the second panel and set current axis
    plt.legend(loc= 'center left', bbox_to_anchor=(1, 0.5))  
    plotName = "SensitivityGraph_"+ param +".png"
    plt.savefig(plotName, dpi=300, bbox_inches = "tight")
    plt.rcParams["figure.figsize"] = (10,3)
    plt.tight_layout() 
    plt.show()