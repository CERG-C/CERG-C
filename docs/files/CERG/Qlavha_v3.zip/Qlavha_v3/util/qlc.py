import configparser

import PyQt5.QtGui as QTG

from . import tree
from PyQt5 import QtWidgets

# ---- #
# Util #
# ---- #

def writeableStr(s):
    s = s.split('(')[0]
    s = s.strip()
    return s.replace(" ", "_")

# ---------------- #
# Loading Settings #
# ---------------- #

def load(ui, path):
    config = configparser.RawConfigParser()
    config.read(path) 
    try:
        tree.iter(
            lambda s      : None,
            lambda s, u, n: loadEntry(ui, config, s, u, n),
            lambda s, n, o: loadSelect(ui, config, s, n, o)
        )
    except: 
        return None

def loadEntry(ui, config, section, uiName, name):
    name = writeableStr(name)
    try:
        widget = getattr(ui, uiName)
        if isinstance(widget, QtWidgets.QCheckBox):
            val = config.getboolean(section, name)
            if val != widget.isChecked():
                widget.click()
        elif isinstance(widget, QtWidgets.QLineEdit):
            val = config.get(section, name)
            widget.setText(val)
        elif isinstance(widget, QtWidgets.QComboBox):
            val = config.get(section, name)
            widget.setCurrentText(val)
            
    except configparser.Error:
        return None

def loadSelect(ui, config, section, name, options):
    selection = config.get(section, writeableStr(name))
    uiName, _ = [__n for __n in options if writeableStr(__n[1]) == selection][0]
    radioBut  = getattr(ui, uiName)
    if not radioBut.isChecked():
        radioBut.click()

# --------------- #
# Saving Settings #
# --------------- #

def save(ui, path):
    config = configparser.RawConfigParser()
    tree.iter(
        lambda s      : config.add_section(s),
        lambda s, u, n: parseEntry(ui, config, s, u, n),
        lambda s, n, o: parseExclusive(ui, config, s, n, o)
    )

    with open(path, 'w') as file:
        config.write(file)

def parseEntry(ui, config, section, uiName, name):
    name = writeableStr(name)
    val  = tree.getUiValue(ui, uiName)
    if val is not None: config.set(section, name, val)

def parseExclusive(ui, config, section, name, options):
    name      = writeableStr(name)
    _, option = [uiName__ for uiName__ in options if tree.getUiValue(ui, uiName__[0])][0]
    config.set(section, name, writeableStr(option))

