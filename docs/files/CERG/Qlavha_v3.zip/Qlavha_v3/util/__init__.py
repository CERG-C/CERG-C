import PyQt5.QtCore as QTC
import numpy as np
import osgeo

# ---------------- #
# Package Contents #
# ---------------- #

# Import any required submodules here, since qgis does not want to load them
# otherwise

from . import qlc
from . import summary
from . import table


# ----------------- #
# General Functions #
# ----------------- #

def loadStringResource(path):
    file = QTC.QFile(path)
    file.open(QTC.QIODevice.ReadOnly | QTC.QFile.Text)
    stream = QTC.QTextStream(file)
    stream.setCodec('UTF-8')
    text = stream.readAll()
    file.close()
    return text

def cToK(deg):
    """ Convert Celcius to Kelvin. """
    return float(deg) + 273.15

def numLength(x):
    """ Calculate the amount of significant digits in number. """
    return len(str(int(round(x))))

def writeErr(path):
    import traceback
    with open(path, 'w') as file:
        traceback.print_exc(file = file)

# ------------- #
# DEM Functions #
# ------------- #

def convertTiffToAsc(src, dst):
    driver  = osgeo.gdal.GetDriverByName('AAIGrid')
    srcFile = osgeo.gdal.Open(src)
    driver.CreateCopy(dst, srcFile)

