"""
This module contains a tree which maps the various ui elements to strings.
"""

import PyQt5.QtGui as QTG
from PyQt5 import QtWidgets

# ----------- #
# Entry Types #
# ----------- #

Entry  = 0 # A key-value entry
Select = 1 # A list of possible options

# ------------- #
# Settings Tree #
# ------------- #

tree = (

    # Input files
    # -----------
    (
        "Input Files",
        (
            (Entry, 'demPathLine', 'dem path'),
            (Entry, 'outputPathLine', 'output path'),
            (Entry, 'outputFileLine', 'output name'),
            (Entry, 'fitnessCheckBox', 'fitness enabled'),
            (Entry, 'fitnessPathLine', 'fitness path')
        )
    ),

    # Vent Location
    # -------------
    (
        "Vent Location",
        (
            (Select, 'vent type',(
                ('pointRadioBut', 'point'),
                ('lineRadioBut', 'line'),
                ('surfaceRadioBut', 'surface'),
                ('layerRadioBut', 'layer'),
                ('pdfRadioBut', 'pdf')
            )),
            (Entry, 'distanceLine', 'vent distance (m)'),
            (Entry, 'x1Line', 'x1'),
            (Entry, 'x2Line', 'x2'),
            (Entry, 'x3Line', 'x3'),
            (Entry, 'x4Line', 'x4'),
            (Entry, 'y1Line', 'y1'),
            (Entry, 'y2Line', 'y2'),
            (Entry, 'y3Line', 'y3'),
            (Entry, 'y4Line', 'y4'),
            (Entry, 'pdfPathLine', 'pdf path'),
            (Entry, 'pdfValueLine', 'pdf min value')
        )
    ),

    # Flow Parameters
    # ---------------
    (
        "Lava Flow Propagation",
        (
            (Entry, 'hcLine', 'hc (m)'),
            (Entry, 'hpLine', 'hp (m)'),
            (Entry, 'h16CheckBox', 'h16 enabled'),
            (Entry, 'squareProbsCheckBox', 'square probabilities enabled'),
        ),
    ),

    # Simulation Parameters
    # ---------------------

    (
        "Simulation Parameters",
        (
            (Entry, 'iterationsLine', 'number of iterations'),
            (Entry, 'thresholdLine', 'threshold (%)'),
        )
    ),

    # Stopping Constraints
    # --------------------

    (
        "Lava Flow Length Constraints",
        (
            (Select, 'length constraint', (
                ('manhattanRadioBut', 'manhattan length'),
                ('euclideanRadioBut', 'euclidean length'),
                ('decreasingProbRadioBut', 'decreasing probability'),
                ('flowgoRadioBut', 'flowgo')
            )),
            # Manhattan length
            (Entry, 'manhattanLine', 'manhattan length (m)'),
            # Euclidean length
            (Entry, 'euclideanLine', 'euclidean length (m)'),
            # Decreasing probability
            (Entry, 'meanLengthLine', 'mean length (m)'),
            (Entry, 'standardDevLine', 'standard deviation (m)'),
            # Flowgo
            (Entry, 'effusionLine', 'effusion rate (m3/s)'),
            (Entry, 'viscosityLine', 'lava_initial viscosity (Pa*s)'),
            (Entry, 'initialCrystLine', 'phenocryst initial mass fractio'),
            (Entry, 'channelRatioLine', 'channel ratio (width/depth)'),
            (Entry, 'advancedParamsCheckBox', 'flowgo advanced enabled'),
            (Entry, 'eruptionLine', 'eruption temp (C)'),
            (Entry, 'crustTempLine', 'crust temp (C)'),
            (Entry, 'tempOffsetLine', 'temp offset (C)'),
            (Entry, 'dLine', 'd'),
            (Entry, 'gravityLine', 'gravity (m/s2)'),
            (Entry, 'growthLine', 'crystal growth rate'),
            (Entry, 'lLine', 'l (J/kg)'),
            (Entry, 'rLine', 'r'),
            (Entry, 'aLine', 'a (1/K)'),
            (Entry, 'bLine', 'b (Pa)'),
            (Entry, 'cLine', 'c (1/K)'),
            (Entry, 'dreLine', 'dre density (kg/m3)'),
            (Entry, 'vesicularityLine', 'vesicularity'),
            (Entry, 'sbcLine', 'sbc (W/m2.K4)'),
            (Entry, 'eLine', 'e'),
            (Entry, 'windSpeedLine', 'wind speed (m/s)'),
            (Entry, 'chLine', 'ch'),
            (Entry, 'airTempLine', 'air temp (C)'),
            (Entry, 'airDensityLine', 'air density (kg/m3)'),
            (Entry, 'heatCapacityLine', 'heat capacity (J/kg.K)'),
            (Entry, 'thicknessLine', 'lava thickness (%)'),
            (Entry, 'crustBaseTempLine', 'crust base temp (C)'),
            (Entry, 'thermalConductivityLine', 'thermal conductivity (W/m.K)')
        )
    ),
     
    # Advanced settings
    # --------------------
            
    (
        "Advanced settings",
        (
            # Sensitivity test
            (Entry, 'sensitivityCheckBox', 'sensitivity enabled'),
            (Entry, 'parameterBox', 'parameter tested for sensitivity'),
            (Entry, 'minValue', 'minimum value'),
            (Entry, 'maxValue', 'maximum value'),
            (Entry, 'stepValue', 'step value'),
            (Entry, 'tableCheckBox', 'table enabled'),
            
        )
    )
)

# ------------- #
# Functionality #
# ------------- #

def isEntry(t):  return t[0] == Entry
def isSelect(t): return t[0] == Select

def iter(sectionCB, entryCB, selectCB):
    for section, entries in tree:
        sectionCB(section)
        for t in entries:
            if isEntry(t):
                entryCB(section, t[1], t[2])
            elif isSelect(t):
                selectCB(section, t[1], t[2])

def getUiValue(ui, name, defaultText = False):
    obj = getattr(ui, name)
    if not obj.isEnabled(): return None
    if  isinstance(obj, QtWidgets.QCheckBox):
        return obj.isChecked()
    elif isinstance(obj, QtWidgets.QRadioButton):
        return obj.isChecked()
    elif isinstance(obj, QtWidgets.QComboBox):
        return obj.currentText()
    elif isinstance(obj, QtWidgets.QLineEdit):
        if obj.text():
            return obj.text()
        if defaultText and obj.placeholderText():
            return obj.placeholderText()
