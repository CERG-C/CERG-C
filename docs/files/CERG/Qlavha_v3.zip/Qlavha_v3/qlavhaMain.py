from PyQt5.QtWidgets import QAction
from PyQt5.QtGui  import QIcon
from PyQt5.QtCore import QObject

from . import resources_rc
from . import ui

class Plugin(object):

    def __init__(self, iface):
        self.iface = iface
        self.standAlone = None

    def initGui(self, standAlone = True):
        """ Load the Q-LavHA GUI or return the required resources to do so.

        This method will create the UI resources which are needed to access
        Q-LavHA from the QGIS interface. After this, two possible things can
        happen:
            - if standAlone is True:
                Q-LavHA is running as a standalone plugin and will add itself
                to the QGIS interface.
            - if standAlone is False:
                Q-LavHA is running as a part of another plugin (such as volcano
                box). In this case, Q-LavHA returns an action that can be
                added to the interface of the parent plugin.

        Arguments:
        standAlone -- Should be False if Q-LavHA is included with another
                      plugin.

        Returns:
        A QAction that can be used to add Q-LavHA to a menu or a toolbar.
        If standAlone is True, nothing is returned.
        """
        self.standAlone = standAlone
        self.icon = QIcon(':/img/logo.png')
        self.action = QAction(self.icon, "Q-LavHA", self.iface.mainWindow())
#        QObject.connect(self.action, SIGNAL("triggered()"), self.loadUI)
        self.action.triggered.connect(self.loadUI)

        if not standAlone: return self.action

        # We only add ourself to the UI if we run in standalone mode
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("Q-LavHA", self.action)

    def unload(self):
        """ Unload the Q-LavHA GUI elements.

        This will unload the Q-LavHA GUI elements.
        If Q-LavHA is not run in standalone mode, the parent plugin should
        perform the unload step.
        """

        self.iface.removePluginMenu("Q-LavHA", self.action)
        self.iface.removeToolBarIcon(self.action)

    def loadUI(self): ui.load(self.iface)

