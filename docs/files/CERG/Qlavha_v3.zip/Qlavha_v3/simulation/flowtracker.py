""" This module provides a class that decides where the lava flows to next.

This functionality is provided in the FlowTracker class.
"""

import math
import random
import numpy as np

# ----------------- #
# Custom Exceptions #
# ----------------- #

class FlowException(Exception):
    """ This type of exception is raised when the lava flow cannot continue. """

class NoPathException(FlowException):
    """ This exception occurs when the lava has no place to flow to. """

class OutOfBoundsException(FlowException):
    """ This exception occurs when the lava would flow beyond the DEM. """

# ------------ #
# Window Class #
# ------------ #

class Window(object):
    """ This class contains the 'window' mechanism used for computing lava flows

    Concretely, this class contains 2 main data elements: an array used for
    computations (the window) and a view on a part of the DEM.

    Using this class should be done through the `setup` and `tryNext` methods.
    The `setup` method prepares the Window for computations based on a given
    lava starting point. The `tryNext` method attempts to find the next location
    for the lava to flow to.

    The use of `setup` was introduced to avoid initializing a new window for
    every 'step' of the lava flow process, as this is a costly process. Instead,
    the window recyles a numpy array which is only initialized once.
    """
    def __init__(self, dem, square, size, noDataAllowed):
        """ Initialize a window class.

        Arguments:
        dem           -- the dem that is being used
        square        -- wether or not the probabilities should be squared when
                         calculating the next location of the lava.
        size          -- The dimensions of the window, this should be an integer
                         as the amount of rows and colums of a window should
                         always be equal.
        noDataAllowed -- The amount of allowed no data fields before the window
                         returns None
        """
        self.dem           = dem
        self.size          = size
        self.square        = square
        self.centerToEdge  = int(math.floor(size / 2))
        self.noDataAllowed = noDataAllowed

        self.window       = np.zeros((size, size))
        self.heights      = None
        self.startCol     = None
        self.startRow     = None
        self.startHeight  = None

    def __getitem__(self, xxx_todo_changeme): (i,j) = xxx_todo_changeme; return self.window[j,i]
    def __setitem__(self, xxx_todo_changeme1, val): (i,j) = xxx_todo_changeme1; self.window[j,i] = val
    def __iter__(self): return next(self)

    def __next__(self):
        """ A generator that can be used to iterate over the window.

        For every 'step', the generator will provide the current element and
        column and row of the element.
        """
        for i, j in self.coordinates():
            yield self.window[j,i], i , j
        iMax, jMax = self.window.shape

    def coordinates(self):
        """ A generator to iterate of the window coordinates. """
        iMax, jMax = self.window.shape
        for i in range(iMax):
            for j in range(jMax):
                yield i, j

    def idxToCoord(self, i, j):
        """ Convert a coordinate in the window to a coordinate in the dem.

        This is done based on the startRow and startCol of the window
        and the given coordinate.
        Concretely, an offset is calculated which determines the distance
        between the central point (startRow, startCol) and the given point.

        Arguments:
        i -- The column of the window that needs to be converted
        j -- The row of the window that needs to be converted

        Returns:
        A tuple (i, j) that contains the matching coordinates in the dem
        """
        return (
            self.startCol + (i - self.centerToEdge),
            self.startRow + (j - self.centerToEdge)
        )

    def checkDimensions(self):
        """ Check if the window does not exceed the bounds of the DEM.

        Returns:
        True if the current window exceeds the bounds of the DEM
        """
        yDim, xDim = self.dem.rows, self.dem.cols
        return (
            self.startCol + self.centerToEdge >= xDim or
            self.startCol - self.centerToEdge <  0    or
            self.startRow + self.centerToEdge >= yDim or
            self.startRow - self.centerToEdge <  0
        )

    def setup(self, startCol, startRow):
        """ Prepare the window for a given starting point.

        This sets up the window for determining the next location of the lava
        based on its current location. This function should be called every time
        the lava moves.

        Arguments:
        startCol -- The current column of the lava in the DEM
        startRow -- The current row of the lava in the DEM

        Raises:
        OutOfBoundsException -- raised if the window for startCol, startRow
                                goes beyond the bounds of the dem
        """
        self.window     *= 0
        self.startCol    = startCol
        self.startRow    = startRow
        self.startHeight = self.dem[startCol, startRow]

        if self.checkDimensions():
            raise OutOfBoundsException()

        self.heights  = self.dem[
            startCol - self.centerToEdge : startCol + self.centerToEdge + 1,
            startRow - self.centerToEdge : startRow + self.centerToEdge + 1
        ]

    def countNoData(self):
        ctr = 0
        for i, j in self.coordinates():
            if self.idxToCoord(i,j) in self.dem.noData:
                ctr +=1
        return ctr

    def checkViable(self):
        """ Verify if we have enough data to provide a reliable target. """
        return self.countNoData() <= self.noDataAllowed

    def calculateOdds(self, lavaHeight):
        """ For every cell, calculate the odds that the lava will travel here

        Arguments:
        lavaHeight -- The height of the lava flow
        """
        self.window *= 0
        self.window += - self.heights + lavaHeight + self.startHeight

    def filterOdds(self, visited):
        """ Set the odds of locations that meet some conditions to zero.

        Conrectly, the lava cannot travel to the following locations:
            - locations for which we have no data
            - locations we already visited
            - our current location
            - locations for which the odds are below zero
        """
        self[self.centerToEdge, self.centerToEdge] = 0
        self.window[self.window < 0] = 0
        for i, j in self.coordinates():
            if self.idxToCoord(i, j) in visited:
                self[i,j] = 0
            elif self.idxToCoord(i, j) in self.dem.noData:
                self[i,j] = 0

    def getSum(self):
        """ Return the sum of the odds present in the window """
        return self.window.sum()

    def normalize(self):
        """ Normalize the odds in the window, square them if required. """
        if self.square: self.window *= self.window
        sum = self.getSum()
        self.window /= sum

    def getNext(self, rand):
        """ Get the location where the lava will flow to next.

        This is done by summing the odds present in the window and returning
        the first coordinate for which the sum of the odds so far exceeds a
        given random number

        Arguments:
        rand -- A random number between 0 and 1 that needs to be exceeded

        Returns:
        The (dem) coordinate where the lava will flow to next.
        """
        sum = 0
        for el, i, j in self:
            sum += el
            if sum >= rand:
                return self.idxToCoord(i,j)

    def tryNext(self, lavaHeight, visited, rand):
        """ Try to find the next lava location.

        Try to find a location for the lava to flow to based on the heights
        in the dem and the height of the lava flow.

        Arguments:
        lavaHeight -- The height of the lava flow
        visited    -- A set which contains the coordinates (in the dem) that
                      have been visited so far.
        rand       -- A random number between 0 and 1 that is used to find the
                      next location.

        Returns:
        A (dem) coordinate where the lava will flow to next or `None` if no such
        point exists.
        """
        if not self.checkViable(): return None

        self.calculateOdds(lavaHeight)
        self.filterOdds(visited)
        sum = self.getSum()

        if sum > 0:
            self.normalize()
            return self.getNext(rand)
        else:
            return None

class SmallWindow(Window):
    """ The small (3 x 3) window type. """
    def __init__(self, dem, square):
        super(SmallWindow, self).__init__(dem, square, 3, 2)

class LargeWindow(Window):
    """ The large (5 x 5) window type. """
    def __init__(self, dem, square):
        super(LargeWindow, self).__init__(dem, square, 5, 4)

# ------------- #
# Tracker Class #
# ------------- #

class FlowTracker(object):
    """ Class that tracks where the lava flows to next.

    This class is a container that uses instances of `Window` to do the heavy
    lifting. The class mainly takes care of using the correct windows with the
    correct arguments when this is needed.
    Besides this, it stores some stateful containers that need to be shared
    between the various instances of window.
    """
    def __init__(self, dem, hc, hp, squaredProbs, useLarge):
        """ Initialize a tracker.

        Arguments:
        dem          -- The dem of the terrain where the lava flows
        hc           -- The average expected height of the lava flow
        hp           -- The maximum potential height of the flow
        noData       -- Collection that contains the cells with no data.
        squaredProbs -- Boolean that indicates if the probabilities should be
                        squared
        useLarge     -- Boolean that indicates if a larger window should be
                        used to determine the lava flow if it cannot be found
                        otherwise
        """
        super(FlowTracker, self).__init__()
        self.squaredProbs = squaredProbs
        self.useLarge     = useLarge
        self.dem          = dem
        self.hc           = hc
        self.hp           = hp

        self.visited      = set()
        self.smallWindow  = SmallWindow(dem, squaredProbs)

        if useLarge:
            self.largeWindow  = LargeWindow(dem, squaredProbs)

    def statelessCopy(self):
        """ Create a tracker with identical arguments but no shared state. """
        return FlowTracker(
            self.dem, self.hc, self.hp, self.squaredProbs, self.useLarge
        )

    def tryNext(self, window, lavaHeight, rand):
        """ Convenience function that tries to find the next location.

        This is done by using the trynext of the window with the appropriate
        parameters. The `visited` set will automatically be updated if a
        location is found.

        Arguments:
        window     -- The window to be used
        lavaHeight -- The height of the lava stream
        rand       -- A random number between 0 and 1 used to determine the next
                      location of the lava.

        Returns:
        A (dem) coordinate where the lava will flow to next or `None` if no such
        point exists.
        """
        loc = window.tryNext(lavaHeight, self.visited, rand)
        if loc is not None:
            self.visited.add(loc)
            return loc

    def findNext(self, startCol, startRow):
        """ Find the next location of the lava stream for a given location.

        This function is the main use of the `FlowTracker` class. It will try to
        find the next location of the lava stream by using various windowing
        techniques with varying parameters. An exception is thrown if this
        is not possible.

        Arguments:
        startCol -- The current column of the lava in the DEM
        startRow -- The current row of the lava in the DEM

        Returns:
        A tuple of the next destination of the lava stream and the height
        added by the calculation.

        Raises:
        NoPathException      -- If no path can be found.
        OutOfBoundsException -- If a possible valid path can only be found
                                outside of the DEM.
        """
        self.smallWindow.setup(startCol, startRow)
        rand = random.random()

        # Try to find the location with hc
        loc = self.tryNext(self.smallWindow, self.hc, rand)
        if loc is not None: return (loc, self.hc)
        # Try to find it with hp
        loc = self.tryNext(self.smallWindow, self.hp, rand)
        if loc is not None: return (loc, self.hp)
        # Try it with the large matrix if it is enabled
        if self.useLarge:
            self.largeWindow.setup(startCol, startRow)
            # Try to find the location with hc
            loc = self.tryNext(self.largeWindow, self.hc, rand)
            if loc is not None: return (loc, self.hc)
            # Try to find the location with hp
            loc = self.tryNext(self.largeWindow, self.hp, rand)
            if loc is not None: return (loc, self.hp)

        raise NoPathException()

