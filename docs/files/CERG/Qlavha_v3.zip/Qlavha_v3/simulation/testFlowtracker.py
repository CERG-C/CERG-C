import unittest

import numpy as np

from dem import DEM
from . import flowtracker


class TestFlowTracker(unittest.TestCase):

    def createDummyDem(self, cols, rows):
        return DEM(np.ones((rows, cols)), 0, 0, 0, set())

    def testidxToCoord(self):
        """ See if we can convert window coordinates to dem coordinates"""
        dem   = self.createDummyDem(10,10)

        small = flowtracker.SmallWindow(dem, False)
        large = flowtracker.LargeWindow(dem, False)

        small.setup(1,1)
        large.setup(2,2)

        self.assertEqual(small.idxToCoord(0,0), (0,0))
        self.assertEqual(small.idxToCoord(1,1), (1,1))
        self.assertEqual(small.idxToCoord(2,1), (2,1))

        self.assertEqual(large.idxToCoord(0,0), (0,0))
        self.assertEqual(large.idxToCoord(1,1), (1,1))
        self.assertEqual(large.idxToCoord(2,1), (2,1))
        self.assertEqual(large.idxToCoord(3,1), (3,1))

        small.setup(4,2)
        large.setup(4,2)

        self.assertEqual(small.idxToCoord(1,1), (4,2))
        self.assertEqual(small.idxToCoord(0,0), (3,1))
        self.assertEqual(small.idxToCoord(1,2), (4,3))

        self.assertEqual(large.idxToCoord(2,2), (4,2))
        self.assertEqual(large.idxToCoord(0,0), (2,0))
        self.assertEqual(large.idxToCoord(4,3), (6,3))

    def testOutofBounds(self):
        """ Test if the windows throws an exception when the flow crosses the
        bounds of the DEM
        """
        dem   = self.createDummyDem(3,3)
        small = flowtracker.SmallWindow(dem, False)
        large = flowtracker.LargeWindow(dem, False)

        # Make sure this does not raise an exception
        small.setup(1,1)
        with self.assertRaises(flowtracker.OutOfBoundsException):
            small.setup(2,2)
        with self.assertRaises(flowtracker.OutOfBoundsException):
            large.setup(1,1)

    def testFilter(self):
        """ Test if the appropriate values are filtered out from the window
        do this with the following DEM:

           visited   | cannot reach |  reachable
           no data   |    center    |    visited
        cannot reach |   reachable  |   no data
        """
        matrix      = np.ones((3,3))
        matrix[1,1] = 2

        # Create some impossible to reach spots, remember that coordinates
        # in the dem are inverted
        matrix[0,1] = 5
        matrix[2,0] = 5

        # Add noData elements
        noData = set()
        noData.add((2,2))
        noData.add((0,1))

        # Create DEM
        dem = DEM(matrix, 0,0,0, noData)

        # Add visited elements
        visited = set()
        visited.add((0,0))
        visited.add((2,1))

        # Calculate a spot
        window = flowtracker.SmallWindow(dem, False)
        window.setup(1,1)
        res = window.tryNext(0, visited, 0.5)

        # Check if center was set to zero
        self.assertEqual(window[1,1], 0, "Center not filtered!")

        # Check if the unreachable spots were set to zero
        self.assertEqual(window[1,0], 0, "Unreachable not filtered!")
        self.assertEqual(window[0,2], 0, "Unreachable not filtered!")

        # Check if the nodata spots were set to zero
        self.assertEqual(window[2,2], 0, "NoData not filtered!")
        self.assertEqual(window[0,1], 0, "NoData not filtered!")

        # Check if the visited were set to zero
        self.assertEqual(window[0,0], 0, "Visited not filtered!")
        self.assertEqual(window[2,1], 0, "Visited not filtered!")

        # Make sure the result is in one of the two remaining valid spots
        self.assertIn(res, [(1,2),(2,0)])

    def testNoData(self):
        """ Test if a NoPathException is raised when NoData is present """
        matrix      = np.ones((3,3))
        matrix[1,1] = 10

        noData = set()
        for i in range(4):
            for j in range(4):
                noData.add((i,j))

        # Create DEM
        demData   = DEM(matrix, 0,0,0, set())
        demNoData = DEM(matrix, 0,0,0, noData)

        # Try to find a path with data
        tracker = flowtracker.FlowTracker(demData, 0, 0, False, False)
        tracker.findNext(1,1)

        # No path should be available with the noData set
        tracker = flowtracker.FlowTracker(demNoData, 0, 0, False, False)
        with self.assertRaises(flowtracker.NoPathException):
            tracker.findNext(1,1)

    def testLarge(self):
        """ Test if the large window is used when needed

        We test this by filling the small window cells with noData and the
        other ones with valid paths.
        """
        matrix      = np.ones((5,5))
        matrix[2,2] = 10

        noData = set()
        for i in range(6):
            for j in range(6):
                if (0 < i < 4) and (0 < j < 4): noData.add((i,j))

        dem = DEM(matrix, 0,0,0, noData)
        trackerSmall = flowtracker.FlowTracker(dem, 0, 0, False, False)
        trackerLarge = flowtracker.FlowTracker(dem, 0, 0, False, True)

        with self.assertRaises(flowtracker.NoPathException):
            trackerSmall.findNext(2,2)

        # Should work
        trackerLarge.findNext(2,2)

    def testHPHC(self):
        """ Test if both Hc and Hp are used """
        dem = np.ones((3,3))
        dem = self.createDummyDem(3,3)

        trackerFail = flowtracker.FlowTracker(dem, 0,0, False, False)
        trackerHc   = flowtracker.FlowTracker(dem, 2,0, False, False)
        trackerHp   = flowtracker.FlowTracker(dem, 0,2, False, False)

        with self.assertRaises(flowtracker.NoPathException):
            trackerFail.findNext(1,1)

        # Both of these should work
        trackerHc.findNext(1,1)
        trackerHp.findNext(1,1)

    def testHeight(self):
        """ Test if the tracker returns the correct height. """
        dem = self.createDummyDem(3,3)

        trackerHc = flowtracker.FlowTracker(dem, 2,0, False, False)
        trackerHp = flowtracker.FlowTracker(dem, 0,2, False, False)

        self.assertEqual(trackerHc.findNext(1,1)[1], 2)
        self.assertEqual(trackerHp.findNext(1,1)[1], 2)

    def testCoordinates(self):
        """ Test if the lava flows correctly when one option is available """
        matrix = np.zeros((3,3))
        matrix.fill(2)
        matrix[1,1] = 1
        matrix[0,0] = 0

        dem = DEM(matrix, 0,0,0, set())
        tracker = flowtracker.FlowTracker(dem, 0,0, False, False)
        self.assertEqual(tracker.findNext(1,1)[0], (0,0))

if __name__ == '__main__': unittest.main()
