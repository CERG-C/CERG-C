from math import atan2, cos, sin, sqrt

# ---------------- #
# Package Contents #
# ---------------- #

# Add the submodules here, since QGIS's embedded python interpreter cannot
# use them otherwise.
from . import raster
from . import fitness
from . import stoptracker
from . import flowtracker

# ----------------- #
# Point Calculation #
# ----------------- #

def convertPoints(dem, lst):
    return [dem.convertCoord(x_y[0],x_y[1]) for x_y in lst]

def flatten(gen):
    for inner in gen:
        for el in inner:
            yield el

def calcLinePoints(dem, distance, x, y):
    return convertPoints(dem, calcLineCoords(dem, distance, x, y))

def calcSurfacePoints(dem, distance, p1, p2, p3, p4):
    return convertPoints(dem, calcSurfaceCoords(dem, distance, p1, p2, p3, p4))

def calcLineCoords(dem, distance, xxx_todo_changeme, xxx_todo_changeme1):
    (xStart, yStart) = xxx_todo_changeme
    (xEnd, yEnd) = xxx_todo_changeme1
    if distance < dem.resolution: distance = dem.resolution
    length = sqrt((xEnd - xStart) ** 2 + (yEnd - yStart) ** 2)
    angle  = atan2(yEnd - yStart, xEnd - xStart)
    steps  = int(length // distance)

    return (
        (
            xStart + (step * distance * cos(angle)),
            yStart + (step * distance * sin(angle))
        )
        for step in range(steps + 1)
    )

def calcSurfaceCoords(dem, distance, xxx_todo_changeme2, xxx_todo_changeme3, xxx_todo_changeme4, xxx_todo_changeme5):
    (x1, y1) = xxx_todo_changeme2
    (x2, y2) = xxx_todo_changeme3
    (x3, y3) = xxx_todo_changeme4
    (x4, y4) = xxx_todo_changeme5
    llX = min(x1, x2, x3, x4)
    llY = min(y1, y2, y3, y4)
    trX = max(x1, x2, x3, x4)
    trY = max(y1, y2, y3, y4)
    points = (
        calcLineCoords(dem, distance, (llX,y), (trX,y))
        for x, y in calcLineCoords(dem, distance, (llX, llY), (llX, trY))
    )
    return flatten(points)

def calcPdfPoints(dem, pdf, thresh, coords):
    points = []
    probs  = []
    for x, y in coords:
        pdfX, pdfY = pdf.convertCoord(x,y)
        prob = pdf[pdfX, pdfY]
        if prob >= thresh:
            points.append(dem.convertCoord(x,y))
            probs.append(prob)
    return (points, probs)

# ------------------ #
# Simulation Control #
# ------------------ #

class SimulationStoppedException(Exception):
    """ This exception is raised when we abort the simulation. """

__RUN_SIMULATION__ = False

def stopSimulation():
    global __RUN_SIMULATION__
    __RUN_SIMULATION__ = False

def enableSimulation():
    global __RUN_SIMULATION__
    __RUN_SIMULATION__ = True

def simulationActive():
    return __RUN_SIMULATION__

# ---------- #
# Simulation #
# ---------- #

def run(dem, flow, stop, iter, threshold, points, probs, progressCallBack):
    if not probs: probs = (1 for el in points)
    #timeSimulation(dem, flow, stop, iter, points, probs, progressCallBack, 100)
    try:
        enableSimulation()
        res = runSimulation(
            dem, flow, stop, iter, points, probs, progressCallBack
        )
    except SimulationStoppedException:
        enableSimulation()
        progressCallBack(0)
        raise SimulationStoppedException()
    else:
        res.matrix /= iter * len(points)
        res.matrix[res.matrix <= threshold] = res.ndVal
        return res

def timeSimulation(dem, flow, stop, iter, points, probs, callback, repetitions):
    import timeit
    func = lambda : runSimulation(
        dem, flow, stop, iter, points, probs, callback
    )
    time = timeit.timeit(func, number = repetitions)
    resStr =  (
        "Total time for %s repetitions: %s seconds.\n"
        "\tAverage time: %s seconds"
    ) % (repetitions, time, time / repetitions)
    print(resStr)

def runSimulation(dem, flow, stop, iter, points, probs, progressCallBack):
    """ Run the simulation for the complete list of points. """
    result = dem.emptyClone()
    for (idx, (ventCol, ventRow)), prob in zip(enumerate(points), probs):
        res = runPoint(
            dem, flow, stop, iter, ventCol, ventRow,
            lambda x : progressCallBack(
                (idx * 100 / len(points)) + (x / len(points))
            )
        )
        res.matrix    *= prob
        result.matrix += res.matrix
    return result

def runPoint(dem, flow, stop, iter, ventCol, ventRow, progressCallBack):
    """ Run all of the iterations for a single point. """
    result = dem.emptyClone()

    progressThreshold = 5 if iter >= 5 else iter
    progressCtr = 0

    for i in range(iter):
        res = runIter(dem, flow, stop, ventCol, ventRow)
        result.matrix += res.matrix

        progressCtr += 1
        if progressCtr == progressThreshold:
            progressCallBack((i + 1) * 100. / iter)
            progressCtr = 0

    return result

def runIter(dem, flow, stop, ventCol, ventRow):
    """ Execute a single operation for a single point. """
    result     = dem.emptyClone()
    posX, posY = ventCol, ventRow
    newX, newY = posX, posY

    flow = flow.statelessCopy()
    stop = stop.statelessCopy()

    while not stop.shouldStop() and simulationActive():
        try:
            result[posX, posY] = stop.pixelValue()
            ((newX, newY), height) = flow.findNext(posX, posY)
            stop.update(posX, posY, newX, newY, height)
            posX, posY = newX, newY
        except flowtracker.FlowException:
            break

    if not simulationActive():
        raise SimulationStoppedException()
    else:
        return result
