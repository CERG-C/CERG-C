""" This module provides classes that can track when the lava flow stops.

The lava flow is tracked by one of 3 different classes, that check this through
different means: LavaLength, LavaAZLenght, DecreasingProbability and FlowGo.

Each of these classes export `update` and `shouldstop` methods.
More information on these methods can be found in the `StopTracker`
documentation, as it provides the interface tracker classes should
adhere to.
"""

import copy

from math import sqrt, exp, sin, atan, erf

# ----------------- #
# Tracker Interface #
# ----------------- #

class StopTracker (object):
    """ Interface for tracker classes.

    This class acts as an abstract base class that supports multiple methods
    of stopping the current iteration of the simulation.
    Concretely, this is done by providing two methods, `update` and
    `shouldStop`. StopTracker classes should provide both of these methods.
    Additionally, the `pixelValue` method can be used to change the probability
    of the current pixel.

    The update method should be called every time the lava flow advances, the
    shouldStop method should be called to figure out if the simulation can end.
    """
    def __init__(self, dem):
        """ Initialize the StopTracker with a dem. """
        super(StopTracker, self).__init__()
        self.dem = dem

    def statelessCopy(self):
        """ Create a tracker with identical arguments but no shared state. """
        return copy.copy(self)

    def calcDistance(self, startCol, startRow, endCol, endRow):
        """ Calculate the distance between two locations. """
        horDist  = self.dem.resolution * (endCol - startCol)
        verDist  = self.dem.resolution * (endRow - startRow)
        return sqrt((horDist ** 2) + (verDist ** 2))

    def update(self, startCol, startRow, endCol, endRow, height):
        """ Update the current state of the tracker.

        Arguments:
        startCol -- The column of the matrix from which the lava flows
        startRow -- The row of the matrix from which the lava flows
        endCol   -- The column of the matrix to which the lava flows
        endRow   -- The row of the matrix to which the lava flows
        height   -- Extra height that is added by the probability calculation
        """
        raise NotImplementedError()

    def shouldStop(self):
        """ Determine if the current iteration of the simulation can end. """
        raise NotImplementedError()

    def pixelValue(self):
        """ Return a value to change the probability of the current pixel. """
        return 1

# ---------------------------- #
# Length-based Stop Conditions #
# ---------------------------- #

class LavaLength (StopTracker):
    """ Stop the flow when a certain distance has been covered.

        This is done by storing the covered distance in the `currentLength`
        attribute. The flow stops when this distance exceeds a given threshold,
        lengthMax.
    """
    def __init__(self, dem, lengthMax):
        super(LavaLength, self).__init__(dem)
        self.lengthMax     = lengthMax
        self.currentLength = 0

    def update(self, startCol, startRow, endCol, endRow, height):
        self.currentLength += self.calcDistance(
            startCol, startRow, endCol, endRow)

    def shouldStop(self):
        return self.currentLength > self.lengthMax
    
class LavaAZLength (StopTracker):
    """ Stop the flow when a certain distance has been covered.
        This is done by stoping the simulation when the crow flies distance 
        is reached. The flow stops when this distance exceeds a given threshold,
        lengthMax.
    """   
    def __init__(self, dem, lengthMax):
        super(LavaAZLength, self).__init__(dem)
        self.lengthMax     = lengthMax
        self.currentLengthAZ = 0
        self.initialcount = 0
                
    def update(self, startCol, startRow, endCol, endRow, height):
        if self.initialcount == 0:
            self.initCol = startCol
            self.initRow = startRow
            self.initialcount += 1
            self.currentLengthAZ = self.calcDistance(
                    self.initCol, self.initRow, endCol, endRow)
            
        else: 
            self.currentLengthAZ = self.calcDistance(
                    self.initCol, self.initRow, endCol, endRow)

    def shouldStop(self):
        return self.currentLengthAZ > self.lengthMax

class DecreasingProbability (LavaAZLength):
    """ Stop the flow when a distance based on probability has been covered."""
    def __init__(self, dem, meanProb, standardDev):
        super(DecreasingProbability, self).__init__(dem, 0)
        self.lengthMax = meanProb + 3 * standardDev
        self.stdev = standardDev
        self.mean  = meanProb

    def pixelValue(self):
        """ Return a value to change the probability of the current pixel. """
        stdevMod  = ((self.stdev ** 2) * 2) ** .5
        lengthMod = self.currentLengthAZ - self.mean
        res       = erf(lengthMod / stdevMod)
        return 1 - 0.5 * (1 + res)

# ---------------------------- #
# Flow-go based Stop Condition #
# ---------------------------- #

class FlowGo (StopTracker):
    """ Stop the flow based on a thermoreological model. """
    def __init__(self, dem, dict):
        super(FlowGo, self).__init__(dem)

        # General
        self.effusionRate                = dict['effusionRate']
        self.channelRatio                = dict['channelRatio']
        self.gravity                     = dict['gravity']

        # Viscosity
        self.initialViscosity            = dict['initialViscosity']
        self.viscosityConstA             = dict['viscosityConstA']
        self.viscosityConstB             = dict['viscosityConstB']
        self.viscosityConstC             = dict['viscosityConstC']

        # Radition
        self.emissivity                  = dict['emissivity']
        self.stephanBoltzmannConst       = dict['stephanBoltzmannConst']

        # Conductivity
        self.crustThickness              = dict['crustThickness']
        self.lavaThermalConductivity     = dict['lavaThermalConductivity']

        # Thermal
        self.crustTemp                   = dict['crustTemp']
        self.eruptionTemp                = dict['eruptionTemp']
        self.crustBaseTemp               = dict['crustBaseTemp']
        self.coreCrustTempOffset         = dict['coreCrustTempOffset']
        self.thermalConductivityConstant = dict['thermalConductivityConstant']

        # Density and Vesicularity
        self.denseRockEquivalentDensity  = dict['denseRockEquivalentDensity']
        self.vesicularity                = dict['vesicularity']
        self.lavaDensity                 = (
            self.denseRockEquivalentDensity * (1 - self.vesicularity)
        )

        # Convection
        self.airTemp                     = dict['airTemp']
        self.windSpeed                   = dict['windSpeed']
        self.airDensity                  = dict['airDensity']
        self.windFriction                = dict['windFriction']
        self.airHeatCapacity             = dict['airHeatCapacity']

        # Crystal
        self.growthRate                  = dict['growthRate']
        self.latentHeat                  = dict['latentHeat']
        self.initialCrystalMass          = dict['initialCrystalMass']
        self.inverseCrystalConc          = dict['inverseCrystalConc']

        # State
        self.couldNotFindDepth           = False
        self.channelDepth                = None
        self.channelWidth                = None
        self.currentVelocity             = None
        self.effusionRateGuess           = None
        self.currentCrystals             = self.initialCrystalMass
        self.currentTemp                 = self.eruptionTemp

    def shouldStop(self):
        return (
            self.couldNotFindDepth or
            (self.currentCrystals * self.inverseCrystalConc) > 1.0 or
            (self.currentVelocity is not None and self.currentVelocity < 0.01)
        )

    def calcSlope(self, startCol, startRow, endCol, endRow, height, dist):
        m                 = self.dem
        heightDiff        = m[startCol, startRow] - m[endCol, endRow] + height
        return atan(heightDiff / dist)

    def updateCooling(self, velocity, distance):
        crustCoverage     = exp(self.thermalConductivityConstant * velocity)
        exposedLavaT      = self.currentTemp - self.coreCrustTempOffset
        self.channelWidth = (
            self.effusionRateGuess / (self.channelDepth * velocity)
        )
        radiation = (
            crustCoverage * (self.crustTemp ** 4) +
            (1 - crustCoverage) * (exposedLavaT ** 4)
        ) ** 0.25
        convection = (
            crustCoverage * (self.crustTemp ** 1.333) +
            (1 - crustCoverage) * (exposedLavaT ** 1.333)
        ) ** 0.75

        radiationTempLoss = (
            self.stephanBoltzmannConst * self.emissivity *
            (radiation ** 4) * self.channelWidth
        )
        forceTempLoss = (
            self.windFriction * self.airDensity * self.airHeatCapacity *
            self.windSpeed * (convection - self.airTemp) * self.channelWidth
        )
        conductivityTempLoss = (
            self.lavaThermalConductivity *
            ((self.currentTemp - self.crustBaseTemp) /
             ((self.crustThickness / 100.) * self.channelDepth )) * self.channelWidth
        )
        coreCooling = (
            - (radiationTempLoss + forceTempLoss + conductivityTempLoss) /
            (
                self.effusionRateGuess * self.lavaDensity *
                self.latentHeat * self.growthRate
            )
        ) * distance

        self.currentVelocity   = velocity
        self.currentTemp      += coreCooling
        self.currentCrystals  += -coreCooling * self.growthRate

    def calcVelocity(self, slope):
        tempDiff          = self.eruptionTemp - self.currentTemp
        yieldStrength     = (
            (6500 * self.currentCrystals ** 2.85) +
            self.viscosityConstB * exp(self.viscosityConstC * tempDiff - 1)
        )
        viscosity         = (
            (1 - self.inverseCrystalConc * self.currentCrystals) ** (-2.5) *
            self.initialViscosity * exp(self.viscosityConstA * tempDiff)
        )
        shearStress       = (
            self.channelDepth * self.lavaDensity * self.gravity * sin(slope)
        )
        yieldStressRatio  = yieldStrength / shearStress
        return (
            (((self.channelDepth ** 2) * self.lavaDensity *
            self.gravity * sin(slope)) / (3 * viscosity)) *
            (1 - ((3./2) * yieldStressRatio) + (.5 * yieldStressRatio ** 3))
        )

    def determineChannel(self, slope):
        guessThreshold    = 0.0001
        effusionRateGuess = 0.

        self.channelDepth = 10.
        channelDepthMax   = 20.0
        channelDepthMin   = 0.0
        prev              = None

        while True:
            velocity = self.calcVelocity(slope)
            self.channelWidth = self.channelDepth * self.channelRatio
            effusionRateGuess = self.channelWidth * self.channelDepth * velocity

            if effusionRateGuess == prev:
                self.didNotUpdate = True
                break

            if (((self.effusionRate - effusionRateGuess) ** 2) <= guessThreshold):
                self.effusionRateGuess = effusionRateGuess
                break

            else:
                prev = effusionRateGuess
                if effusionRateGuess > self.effusionRate:
                    channelDepthMax = self.channelDepth
                else:
                    channelDepthMin = self.channelDepth
                self.channelDepth = (channelDepthMax + channelDepthMin) / 2.0

    def update(self, sCol, sRow, eCol, eRow, h):
        distance   = self.calcDistance(sRow, sCol, eRow, eCol)
        slope      = self.calcSlope(sCol, sRow, eCol, eRow, h, distance)

        if self.channelDepth is None:
            self.determineChannel(slope)

        velocity = self.calcVelocity(slope)
        self.updateCooling(velocity, distance)

