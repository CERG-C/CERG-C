"""
This module is responsible for calculating the fitness index of a lava flow.
The fitness index compares the result of a simulation with a reference file.
"""

import math

import numpy as np

class FitnessResolutionException(Exception):
    """ This exeception is raised when the resolution of the reference and
    simulation do not match.
    """

def replaceNoData(raster):
    # change the nodata value to 0 to work around a numpy limitation
    raster.matrix[raster.matrix == raster.ndVal] = 0
    raster.ndVal = 0

def calcSize(simulation, reference):
    simTrX, simTrY = simulation.getTopRightCoord()
    refTrX, refTrY = reference.getTopRightCoord()
    resolution     = simulation.resolution
    trX  = max(simTrX, refTrX)
    trY  = max(simTrY, refTrY)
    llX  = min(simulation.llX, reference.llX)
    llY  = min(simulation.llY, reference.llY)
    rows = math.ceil((trY - llY) / resolution)
    cols = math.ceil((trX - llX) / resolution)
    return (rows, cols, llX, llY)

def pad(raster, rows, cols, llX, llY):
    replaceNoData(raster)
    res = raster.resolution
    leftPadding   = int((raster.llX - llX) // res)
    rightPadding  = int((cols - raster.cols) - leftPadding)
    bottomPadding = int((raster.llY - llY) // res)
    topPadding    = int((rows - raster.rows) - bottomPadding)
    return np.pad(
        raster.matrix,
        ((topPadding, bottomPadding), (leftPadding, rightPadding)),
        'constant', constant_values = raster.ndVal
    )

def doesSizeMatch(simulation, reference):
    if round(simulation.resolution, 2) != round(reference.resolution, 2):
        raise FitnessResolutionException()
    return (
        simulation.llX == reference.llX and
        simulation.llY == reference.llY and
        simulation.rows == reference.rows and
        simulation.cols == reference.cols
    )

def raster(simulation, reference):
    result = simulation.clone()

    if not doesSizeMatch(simulation, reference):
        rows, cols, llX, llY = calcSize(result, reference)
        reference.matrix = pad(reference, rows, cols, llX, llY)
        result.matrix    = pad(result, rows, cols, llX, llY)
        reference.rows   = rows
        reference.cols   = cols
        reference.llX    = llX
        reference.llY    = llY
        result.rows      = rows
        result.cols      = cols
        result.llX       = llX
        result.llY       = llY
    
    #extract the value from the result.matrix except the NoData
    simMatrixValue = np.ma.masked_values(result.matrix, result.ndVal)
    #cumulate the value
    simProb = simMatrixValue.sum()
        
    result.matrix[result.matrix != result.ndVal] = 1
    result.matrix[result.matrix == result.ndVal] = 0
    reference.matrix[reference.matrix != reference.ndVal] = 10
    reference.matrix[reference.matrix == reference.ndVal] = 0
    reference.matrix[reference.matrix == 0] = 0
    tPosMatrixValue = simMatrixValue * (reference.matrix/10)
    #cumulate the value
    tPosProb = tPosMatrixValue.sum()
    result.matrix += reference.matrix
    result.matrix[result.matrix == 0] = result.ndVal
        
    return result, simProb, tPosProb

def calculate(simulation, reference):
    fitness = raster(simulation, reference)[0]
    simProb = raster(simulation, reference)[1]
    tPosProb = raster(simulation, reference)[2]
    values  = (fitness.matrix != fitness.ndVal).sum()
    tPos    = float((fitness.matrix == 11).sum())
    fPos    = float((fitness.matrix == 1).sum())
    fNeg    = float((fitness.matrix == 10).sum())
    #composite score defined in Dille et al. 2020
    CP = float(((tPos/values)*((1-(fPos/values))**(1/2))*((1-(fNeg/values))**(2))))
    tPos = tPos /values
    fPos = fPos /values
    fNeg = fNeg /values
    
    #probability within the flow
    cumIn = (100/simProb*tPosProb)/100
    cumOut = 1-cumIn
    
    #round it up to 4 decimals
    
    tPos = float("%.4f" % round(tPos, 4))
    fPos = float("%.4f" % round(fPos, 4))
    fNeg = float("%.4f" % round(fNeg, 4))
    CP = float("%.4f" % round(CP, 4))
    cumIn = float("%.4f" % round(cumIn, 4))
    cumOut = float("%.4f" % round(cumOut, 4))
    
    return (tPos, fPos, fNeg, CP, cumIn, cumOut)