""" This module provides a thin wrapper class around a raster."""

import shutil
import os.path

import numpy as np

class AscReadException(Exception):
    """ This exception is raised when the asc file could not be read. """

class AscResolutionException(Exception):
    """ This exception is raised when the dx and dy of an asc file do not
    match. """

class Raster(object):
    def __init__(self, matrix, resolution, llX, llY, noData, ndVal, path):
        self.path       = path
        self.name       = self.getName()

        self.matrix     = matrix
        self.resolution = resolution

        self.ndVal  = ndVal
        self.noData = noData

        self.llX  = llX
        self.llY  = llY

        self.rows, self.cols = self.matrix.shape

    @classmethod
    def fromAsc(cls, path):
        with open(path, 'r') as file:
            _      = int(file.readline().split()[1])
            _      = int(file.readline().split()[1])
            llx    = float(file.readline().split()[1])
            lly    = float(file.readline().split()[1])

            resStr, res = file.readline().split()
            res = float(res)
            if resStr == "dx":
                dy = float(file.readline().split()[1])
                if round(res, 0) != round(dy, 0):
                    raise AscResolutionException()

            ndval  = float(file.readline().split()[1])
            matrix = np.loadtxt(file)

        noData = Raster.getNoDataIndices(matrix, ndval)
        return cls(matrix, res, llx, lly, noData, ndval, path)

    @staticmethod
    def getNoDataIndices(matrix, val):
        res = set()
        rows, cols = np.where(matrix == val)
        for j, i in zip(rows, cols): res.add((i,j))
        return res

    def toAsc(self, path):
        self.copyproj(path)
        self.setNoDataIndices()
        format = '%-13s%s'
        header = [
            ('ncols'        , self.cols),
            ('nrows'        , self.rows),
            ('xllcorner'    , self.llX),
            ('yllcorner'    , self.llY),
            ('cellsize'     , self.resolution),
            ('NODATA_value' , self.ndVal)
        ]
        header = '\n'.join([format % tup for tup in header]) + '\n'
        self.path = path + '.asc'
        self.name = self.getName()
        with open(self.path, 'w') as file:
            file.write(header)
            np.savetxt(file, self.matrix, fmt = '%s')

    def copyproj(self, path):
        src = os.path.splitext(self.path)[0] + '.prj'
        if os.path.exists(src):
            shutil.copy(src, path + '.prj')

    def getName(self):
        return os.path.basename(os.path.splitext(self.path)[0])

    def setNoDataIndices(self):
        for i, j in self.noData:
            self[i,j] = self.ndVal

    def emptyClone(self):
        return Raster(
            np.zeros((self.matrix.shape)),
            self.resolution,
            self.llX, self.llY,
            self.noData,
            self.ndVal,
            self.path
        )

    def clone(self):
        return Raster(
            self.matrix.copy(),
            self.resolution,
            self.llX, self.llY,
            self.noData,
            self.ndVal,
            self.path
        )

    def __getitem__(self, xxx_todo_changeme):
        (i,j) = xxx_todo_changeme
        return self.matrix[(j,i)]

    def __setitem__(self, xxx_todo_changeme1, val):
        (i,j) = xxx_todo_changeme1
        self.matrix[(j,i)] = val

    def convertCoord(self, x, y):
        tlY = self.llY + self.rows * self.resolution
        res = (
            int((x - self.llX) // self.resolution),
            int((tlY - y)      // self.resolution)
        )
        if y == self.llY:
            return (res[0], res[1] - 1)
        else:
            return res

    def checkCoord(self, x, y):
        trX, trY = self.getTopRightCoord()
        llX, llY = self.llX, self.llY
        return (
            llX <= x <= trX and
            llY <= y <= trY
        )

    def getTopRightCoord(self):
        trX = self.llX + self.cols * self.resolution
        trY = self.llY + self.rows * self.resolution
        return trX, trY
