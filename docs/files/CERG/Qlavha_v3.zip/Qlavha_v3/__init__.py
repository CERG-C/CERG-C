#!/usr/bin/env python

""" Initialize the lava plugin. """

def classFactory(iface):
    from . import qlavhaMain
    return qlavhaMain.Plugin(iface)
