# About

[Q-LavHA](http://we.vub.ac.be/en/q-lavha) (**Q**uantum-**L**ava **H**azard
**A**ssessment) *(Mossoux et al. 2016)* is a QGIS (Quantum Geographic
Information System) freeware plugin which simulates lava flow invasion
probability from one or regularly distributed eruptive vents on a Digital
Elevation Model.
It combines existing probabilistic and thermo-rheological models and proposes
improvements and alternatives in order to refine the probability of lava flow
spatial spread and terminal length.
The spatial spread is constrained by the probabilistic steepest slope following
the approach of *Felpeto et al. (2001)*.
Corrective factors are included to allow the lava flow simulation to overcome
small topographical obstacles and fill pits.
The terminal length of the lava flow simulation can be determined based on a
fixed length value, a statistical length probability function or based on the
thermo-rheological properties of an open-channel lava flow following the
approach of the FLOWGO model *(Harris and Rowland 2001)*.

Q-LavHA is designed for scientists and stakeholders confronted with imminent or
long-term lava flow hazard from basaltic volcanoes.
Q-LavHA can improve their understanding of the spatial distribution of lava
flow hazard, influence their land use decisions and support evacuation planning
during a volcanic crisis.

Because of the diversity of its uses, Q-LavHA has been developed in Python in
order to allow users to adapt the code to their needs. Its availability as a
Quantum GIS plugin with a user friendly interface facilitates its distribution
and its use by the community.

If you want to know more about Q-LavHA, you are kindly invited to read the
[manual](http://we.vub.ac.be/sites/default/files/files/q-lavha/Usersguide_Q-LavHA_V2_2017.pdf),
which is also included with the code as `Usersguide_Q-LavHA_V2_2017.pdf`.

## References

Mossoux, S., Saey, M., Bartolini, S., Poppe, S., Canters, F., Kervyn, M., 2016.
*Q-LAVHA: A flexible GIS plugin to simulate lava flows.*
Comput. Geosci., 97, 98–109.

Felpeto, A., Araña, V., Ortiz, R., Astiz, M., García, A., 2001.
*Assessment and modelling of lava flow hazard on Lanzarote (Canary Islands).*
Nat. hazards 23, 247–257.

Harris, A.J.L., Rowland, S.K., 2001.
*FLOWGO: a kinematic thermo-rheologica model for lava flowing in a channel.*
Bull. Volcanol. 63, 20–44.

# Installation

Simply add the Q-LavHA source code to your qgis plugin folder, no further setup
is required. If you do not know what this means, please check the user guide
for further details.
Q-LavHA was developed for QGIS 2.14.
Please ensure that you are using QGIS version 2.14 or higher when using Q-LavHA.

# More Volcano Plugins

Q-LavHA is part of VOLCANBOX which is a new software platform containing
different e-tools aimed at minimizing the risk in volcanic environments.
To know more about these tools, check

* [http://www.gvb-csic.es/software-y-database/index.html](http://www.gvb-csic.es/software-y-database/index.html)
* [http://www.vetools.eu](http://www.vetools.eu)

